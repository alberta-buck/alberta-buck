/**
 * node.ts — the execution-only EIP-1193 node.
 *
 * Design: sits BETWEEN bare `EVM.runCall` (no blocks/receipts/logs) and a full
 * node (heavy). Runs on `@ethereumjs/vm` through the engine seam (see ./engine.ts)
 * + a minimal mock blockchain with `SimpleStateManager` (plain Maps, NO trie, NO
 * state-root) and NONE of the node / RPC / mempool / signing bloat. Every node
 * runs on that one flat state; a node with `computeStateRoot: true` additionally DERIVES
 * a Merkle-Patricia trie from it at the end of each block (./derived-trie.ts,
 * `docs/adr/0014-the-trie-is-derived-from-the-flat-state-not-a-state-manager.md`).
 *
 * It is EXECUTION-ONLY:
 *   - NO account methods (eth_sendTransaction, eth_accounts, eth_sign,
 *     personal_x, wallet_x). Signing is client-side; node takes signed RAW txs.
 *   - Unsupported methods throw a real JSON-RPC method-not-found (-32601) — it
 *     NEVER fakes a success.
 *
 * BOTH halves of execution run on a swappable ENGINE (see ./engine.ts), defaulting
 * to this VM's own `@ethereumjs/evm`: the READ path (`eth_call`,
 * `eth_estimateGas`, `eth_fillTransaction`'s estimation) through `engine.call`,
 * and the MINING path through `engine.transact`. What stays the node's either way:
 * block construction, `cumulativeGasUsed`, receipt assembly, the RPC layer,
 * transaction parsing and sender recovery.
 *
 * Transport-agnostic: just `request()` (async) + mine/dump/load. Knows nothing
 * about Workers — see ./worker-entry.ts for the optional comlink wrapper.
 *
 * ONE THING AT A TIME. Every public entry point on the returned node —
 * `request`, `mine`, `dumpState`, `loadState`, `getStateRoot` — runs through
 * {@link SlimNode}'s serialisation point, so this node executes exactly one
 * request at a time no matter how many are in flight. It is not an optimisation
 * and it is not politeness: the node's state manager is a STACK of checkpoints
 * shared by reads and transactions alike, `commit()` merges downward and
 * `revert()` discards without either knowing who opened the level it acts on, so
 * two overlapping executions destroy each other's writes. See the comment at
 * `serialise` below and
 * `docs/adr/0012-one-request-at-a-time-the-node-serialises-its-whole-public-surface.md`.
 */
import {createVM, type VM} from '@ethereumjs/vm';
import {DerivedStateTrie} from './derived-trie.js';
import {
	OverlayStorageStateManager,
	copyAccount,
	mergeChangeSetOlderWins,
	type ChangeSet,
} from './state-manager.js';
import {
	packAddressKey,
	packSlotKey,
	unpackAddressKey,
	unpackSlotKey,
} from './storage-keys.js';
import {Common, Mainnet, Hardfork} from '@ethereumjs/common';
import {createBlock, type Block} from '@ethereumjs/block';
import {createTxFromRLP, createTx, type TypedTransaction} from '@ethereumjs/tx';
import {
	createAddressFromString,
	createAccountFromRLP,
	type Address,
	Account,
	hexToBytes as hexToBytesStrict,
	bytesToHex,
	bytesToBigInt,
	bigIntToHex,
	setLengthLeft,
	bigIntToBytes,
	unpadBytes,
} from '@ethereumjs/util';

// `@ethereumjs/util`'s hexToBytes is typed to require a `0x${string}` literal.
// Our hex comes from runtime sources (RPC params, serialized state) typed as
// plain `string`, so wrap it once with a runtime 0x-guard rather than casting at
// every call site. Throws on malformed input (same as the underlying fn).
function hexToBytes(s: string): Uint8Array {
	return hexToBytesStrict((s.startsWith('0x') ? s : '0x' + s) as `0x${string}`);
}
import {keccak_256} from '@noble/hashes/sha3.js';
import {connectEngine, createEthereumjsEngine} from './engine.js';
// Sender derivation stays the node's on every engine; what an engine may lend it
// is the CURVE step. See ./sender-recovery.ts.
import {recoverSender} from './sender-recovery.js';
// `serveOn(port)`: EIP-1193 `request` over a MessagePort, in the wire format the
// consumer's `providerOverPort` speaks. Imported HERE, the one place the node's
// public surface is built, so every node (main-thread or worker-hosted) serves a
// port the same way; see `serveOn` at the bottom of this file for why this is a
// dependency of the core rather than of `webevm/worker-host` alone.
import {serveProvider, type ServedProvider} from '@eip-1193/over-port';
// The engine reports EXECUTION gas for a read and the node adds intrinsic gas on top;
// an engine that charges intrinsic gas itself (revm) subtracts the SAME formula,
// so it has exactly one home. See ./intrinsic-gas.ts.
import {
	accessListGas,
	intrinsicGas as intrinsicGasOf,
} from './intrinsic-gas.js';
import {
	RpcError,
	type NodeOptions,
	type ReadCallResult,
	type Engine,
	type SenderMode,
	type SlimNode,
	type RequestArguments,
	type SerializedState,
	type SerializedBlock,
	type SerializedReceipt,
	type SerializedLog,
	type SerializedTx,
	type SerializedHistoryBlock,
} from './types.js';

const ZERO_HASH = '0x' + '00'.repeat(32);
const ZERO_ADDRESS = '0x' + '00'.repeat(20);
/**
 * What a block's `logsBloom` reads as when it admits nothing: a block with no
 * logs, and the defensive fallback for a stored header carrying none at all
 * (`loadState` rebuilds one for an older dump, so this is reached only by a
 * hand-built `SerializedBlock`). It is NO LONGER what EVERY block reports, which
 * is what it was until 2026-08-11 — see `blockToRpc`.
 */
const EMPTY_LOGS_BLOOM = '0x' + '00'.repeat(256);

/**
 * How much gas an `eth_call` / `eth_estimateGas` that names none may burn. A
 * node-wide CONSTANT, not the node's `blockGasLimit`: the two are the same
 * number by default and are still decided apart, for the reasons recorded at its
 * one use site in `evmCall`.
 */
const DEFAULT_READ_BUDGET = 30_000_000n;

/**
 * HOW MANY EXECUTIONS `eth_estimateGas`'s SEARCH MAY SPEND, after the two it
 * always spends (the run at the upper bound, and the one that confirms the
 * measured consumption).
 *
 * The bound is not a safety net for a search that might not terminate — the
 * search below bisects a bigint window and always does — it is a COST CEILING.
 * This node runs in a browser tab and every probe is a full execution of the
 * request, so an estimate is the one read that can cost tens of them.
 *
 * WHY THIS MANY. Bisection alone closes any window this node can produce
 * (30,000,000 gas at the widest) in 25 halvings, and the search reaches phase 2
 * with a window far narrower than that — so 32 is enough to be EXACT for every
 * transaction whose minimum limit is near what it consumes, which is every
 * transaction that is not deliberately gas-sensitive. What can exhaust it is a
 * contract that reads `GAS` and spends what it finds: there the search stops and
 * returns the smallest limit it has PROVEN to succeed, an over-estimate, which is
 * the safe direction (unused gas is not charged, while an under-estimate is a
 * transaction that runs out of gas in the user's face).
 */
const MAX_ESTIMATE_PROBES = 32n;

/**
 * A standard `Error(string)` revert reason, if that is what these bytes are.
 *
 * Used to put WHY into the failure `eth_estimateGas` throws when a request
 * cannot succeed at ANY gas limit. The raw bytes travel on the error's `data`
 * as they always have (a client decodes them), but a human reading a console
 * gets the sentence too.
 *
 * DEFENSIVE BY CONSTRUCTION: it decodes the one shape Solidity emits for
 * `require(false, "...")` / `revert("...")` and answers `undefined` for
 * everything else — a custom error, a bare `revert()`, a halt with no data,
 * truncated bytes. Never throws: an estimate must not fail differently because
 * a callee reverted in a shape this decoder does not know.
 */
function revertReason(returnValue: Uint8Array): string | undefined {
	// 4-byte selector of `Error(string)` + head (32) + length (32).
	if (returnValue.length < 68) return undefined;
	if (
		returnValue[0] !== 0x08 ||
		returnValue[1] !== 0xc3 ||
		returnValue[2] !== 0x79 ||
		returnValue[3] !== 0xa0
	)
		return undefined;
	try {
		// THE HEAD OFFSET IS CHECKED, not assumed. A `revert("...")` from any
		// compiler puts the string's data immediately after the head, i.e. offset
		// 0x20, and the length is then the word at [36,68). A legal-but-unusual
		// encoding with a different offset would make that word something else
		// entirely, and decoding it as a length yields a plausible-looking garbled
		// sentence in an error message — worse than no sentence at all.
		if (bytesToBigInt(returnValue.subarray(4, 36)) !== 32n) return undefined;
		const length = Number(bytesToBigInt(returnValue.subarray(36, 68)));
		if (length === 0 || 68 + length > returnValue.length) return undefined;
		const text = new TextDecoder().decode(
			returnValue.subarray(68, 68 + length),
		);
		return text.length > 0 ? text : undefined;
	} catch {
		return undefined;
	}
}

function hex(b: Uint8Array): string {
	return bytesToHex(b) as string;
}
function numHex(n: number | bigint): string {
	return bigIntToHex(BigInt(n));
}

/**
 * A change set as the dump carries it ({@link SerializedHistoryBlock}): keys in
 * `0x` hex, values hex, `null` for absent. Reads `changes` and does not keep a
 * reference to anything in it.
 */
function serializeChangeSet(
	number: number,
	changes: ChangeSet,
): SerializedHistoryBlock {
	const accounts: Record<string, string | null> = {};
	for (const [key, account] of changes.accounts)
		accounts[key] = account === undefined ? null : hex(account.serialize());
	const code: Record<string, string | null> = {};
	for (const [key, value] of changes.code)
		code[key] = value === undefined ? null : hex(value);
	const storage: Record<string, Record<string, string | null>> = {};
	for (const [addressKey, slots] of changes.storage) {
		const out: Record<string, string | null> = {};
		for (const [slotKey, value] of slots)
			out[unpackSlotKey(slotKey)] = value === undefined ? null : hex(value);
		storage[unpackAddressKey(addressKey)] = out;
	}
	return {
		number,
		accounts,
		code,
		storage,
		storageCleared: [...changes.storageCleared].map(unpackAddressKey),
	};
}

/**
 * Merge serialized record `newer` INTO `older`, the OLDER entry winning for a
 * key both name: the serialized twin of `mergeChangeSetOlderWins`, used by
 * `dumpState` to fold the open record into the head's record (see there).
 */
function mergeSerializedOlderWins(
	older: SerializedHistoryBlock,
	newer: SerializedHistoryBlock,
): void {
	for (const [key, value] of Object.entries(newer.accounts))
		if (!(key in older.accounts)) older.accounts[key] = value;
	for (const [key, value] of Object.entries(newer.code))
		if (!(key in older.code)) older.code[key] = value;
	for (const [address, slots] of Object.entries(newer.storage)) {
		const target = (older.storage[address] ??= {});
		for (const [slot, value] of Object.entries(slots))
			if (!(slot in target)) target[slot] = value;
	}
	for (const address of newer.storageCleared)
		if (!older.storageCleared.includes(address))
			older.storageCleared.push(address);
}

/**
 * The inverse of {@link serializeChangeSet}: keys back to the representation's
 * own (`address.toString()` for accounts and code, PACKED for storage), `null`
 * back to `undefined`. Addresses are lowercased, so a hand-edited checksummed
 * key still names the account the maps hold.
 */
function deserializeChangeSet(record: SerializedHistoryBlock): ChangeSet {
	const accounts = new Map<string, Account | undefined>();
	for (const [key, value] of Object.entries(record.accounts))
		accounts.set(
			key.toLowerCase(),
			value === null ? undefined : createAccountFromRLP(hexToBytes(value)),
		);
	const code = new Map<string, Uint8Array | undefined>();
	for (const [key, value] of Object.entries(record.code))
		code.set(key.toLowerCase(), value === null ? undefined : hexToBytes(value));
	const storage: ChangeSet['storage'] = new Map();
	for (const [address, slots] of Object.entries(record.storage)) {
		const out = new Map<string, Uint8Array | undefined>();
		for (const [slot, value] of Object.entries(slots))
			out.set(
				packSlotKey(hexToBytes(slot)),
				value === null ? undefined : hexToBytes(value),
			);
		storage.set(packAddressKey(hexToBytes(address)), out);
	}
	return {
		accounts,
		code,
		storage,
		storageCleared: new Set(
			record.storageCleared.map((a) => packAddressKey(hexToBytes(a))),
		),
	};
}
function txHashOf(tx: TypedTransaction): string {
	return hex(tx.hash());
}

/**
 * Intrinsic gas: 21000 base (+32000 create) + calldata (16/non-zero, 4/zero) +
 * the EIP-3860 initcode word cost (2 gas per 32-byte word) for creates, from
 * Shanghai on. An engine reports EXECUTION gas only (`runCall`'s
 * `executionGasUsed` omits all of this), so the node adds it back: it is what a
 * transaction pays before its first opcode, and therefore the part of a gas LIMIT
 * that never reaches the frame. `eth_estimateGas` uses it as the LOWER BOUND of
 * its search (see `estimateGas` below), not as the answer.
 *
 * `common` is threaded rather than captured, and it is THE node's `Common` — the
 * same instance the engine is handed at `connect`, so the two callers of the
 * shared formula cannot name different forks. See ./intrinsic-gas.ts.
 */
function intrinsicGas(
	dataHex: string,
	isCreate: boolean,
	common: Common,
): bigint {
	return intrinsicGasOf(
		hexToBytes(dataHex.startsWith('0x') ? dataHex : '0x' + dataHex),
		isCreate,
		common,
	);
}

/**
 * WHAT A SENDER MUST BE ABLE TO PAY BEFORE THE TRANSACTION RUNS: its value plus
 * its WHOLE gas limit at the MAXIMUM fee it offered.
 *
 * THE MAX FEE, NOT THE EFFECTIVE ONE, and that is the protocol's own line rather
 * than a conservative choice: EIP-1559 states it as `assert balance >= gas_limit
 * * max_fee_per_gas`, and both engines enforce exactly that — measured to the
 * wei, on both, in
 * `docs/spikes/replayed-and-invalid-transactions-are-rejected-as-the-nodes-own-errors/measurements.md`.
 * A node checking the EFFECTIVE price instead would admit a window of
 * transactions (`gasLimit * (maxFee - effective)` wide) that both engines then
 * refuse in their own words.
 *
 * THIS IS NOT A SECOND IMPLEMENTATION OF THE FEE ARITHMETIC. What a transaction
 * COSTS is the engine's and has exactly one implementation per engine (the
 * `effectiveGasPrice` on the receipt is the engine's own number, never
 * recomputed here — see ./engine.ts and `test/revm-fees.spec.ts`). This is an
 * ADMISSION rule: what the sender must be able to cover for the transaction to be
 * executable at all, which is the node's question because the node decides what
 * goes into the blocks it builds.
 *
 * A TYPE-3 (BLOB) TRANSACTION IS UNDERSTATED HERE by its blob fee
 * (`blobGas * maxFeePerBlobGas`), which is part of the same assertion in EIP-4844.
 * That is the known type-3 gap this node documents rather than closes (the seam
 * carries no blob fields at all), and the engines' own checks are the backstop:
 * the node admits such a transaction and the engine refuses it in its own words.
 */
function upfrontCost(tx: TypedTransaction): bigint {
	const anyTx = tx as any;
	const perGas: bigint =
		anyTx.maxFeePerGas !== undefined && anyTx.maxFeePerGas !== null
			? anyTx.maxFeePerGas
			: (anyTx.gasPrice as bigint);
	return (anyTx.value ?? 0n) + tx.gasLimit * perGas;
}

interface StoredBlock {
	block: Block;
	header: SerializedBlock;
	logs: SerializedLog[];
}

/**
 * The no-op the node's serialisation chain passes in BOTH handler positions
 * (`run.then(swallow, swallow)`), which is what keeps the chain alive across a
 * FAILED request: `tail` must always be a promise that FULFILS, since a rejection
 * left on it would reject every request queued behind the one that failed and turn
 * one bad transaction into a dead node. It takes no arguments because it uses
 * neither the value nor the reason; both are the caller's, and both have already
 * been delivered to whoever awaited that request.
 */
function swallow(): void {}

/**
 * ONE ACCOUNT'S WORTH OF STATE TO WRITE into the checkpoint a pure read opens
 * (`withStateEntries` in {@link createNodeWithInternals}), already parsed so it
 * cannot fail to apply. Two producers, one apply step (`applyStateEntry`):
 * the geth-style state overrides of `eth_call` / `eth_estimateGas`
 * (`parseStateOverrides`), and block K's state for a call pinned to K
 * (`historicalEntries`, from the `stateHistory` undo log). INTERNAL: not RPC
 * JSON, and not exported.
 */
interface StateEntry {
	readonly address: Address;
	/** The address's code; written FIRST (it rewrites, or creates, the account). */
	code?: Uint8Array;
	/** A WHOLE account (history), replacing whatever is there. */
	account?: Account;
	/** Override fields, a read-modify-write on the account. */
	balance?: bigint;
	nonce?: bigint;
	/** Clear the account's storage before `slots` are written. */
	clearStorage: boolean;
	/** Slot writes, keys 32 bytes, values in shortest form. */
	slots: {key: Uint8Array; value: Uint8Array}[];
	/** The account is ABSENT: emptied code, then deleted, as the LAST step. */
	absent: boolean;
}

/**
 * ONE SUBMITTED TRANSACTION, as the node carries it from `eth_sendRawTransaction*`
 * (or the `evm_*As` cheats) to the block it is mined in: the parsed transaction,
 * its wire bytes (`dumpState` and `eth_getTransactionByHash` report them) and
 * WHO SENT IT.
 *
 * The sender is here — rather than being asked of `tx` at each of the three places
 * that need it — because it is only sometimes recoverable FROM the transaction:
 * `senderMode:'trusted'` states it instead (ADR 0002), and it may then differ from
 * whatever the signature recovers to. `parseTx` decides it ONCE per transaction,
 * and that one value becomes the engine's `TransactionRequest.sender`, the
 * receipt's `from`, and the `from` on the stored transaction.
 */
interface SubmittedTx {
	readonly tx: TypedTransaction;
	readonly raw: Uint8Array;
	readonly sender: Address;
}

/**
 * Switches the node's INTERNAL machinery on that no {@link NodeOptions} field
 * exposes yet. NOT exported from `src/index.ts`: only this package's own tests
 * and the next tasks reach it.
 */
export interface NodeInternals {
	/**
	 * Record the per-block CHANGE SET (the open record of prior values; see the
	 * header of ./state-manager.ts). Off by default, and a node with it off
	 * records nothing and pays nothing. `stateHistory` turns it on (and RETAINS
	 * the records); `computeStateRoot: true` does too (the change set is the list of
	 * keys the derived trie rehashes, ./derived-trie.ts). This flag turns on
	 * recording alone, for the tests, through {@link createNodeWithInternals}.
	 */
	recordChangeSets?: boolean;
}

/**
 * What {@link changeSetsForTests} returns: the change set of the HEAD block
 * (taken when it was mined) and the OPEN record (every write since), as live
 * read-only references. `recording: false` and both `undefined` on a node that
 * does not record.
 */
export interface ChangeSetProbe {
	recording: boolean;
	/**
	 * The block numbers whose change set the node RETAINS as a sealed undo record
	 * (`stateHistory`), oldest first. Empty on a node without history.
	 */
	sealedBlocks: readonly number[];
	/** What the last MINED block changed, with each key's value at the end of the block before it. */
	headBlock: ChangeSet | undefined;
	/** Every write since the head was mined (cheats, a loaded baseline is cleared). */
	open: ChangeSet | undefined;
}

const changeSetProbes = new WeakMap<SlimNode, () => ChangeSetProbe>();

/**
 * TEST-ONLY ACCESSOR for a node's change sets, named as such: it hands out the
 * node's own record objects (read-only by contract) so a test can hold them
 * against the state it reads through the public surface. Not part of
 * `SlimNode` (the worker proxy's shape test would otherwise demand it cross a
 * comlink boundary) and not exported from `src/index.ts`.
 */
export function changeSetsForTests(node: SlimNode): ChangeSetProbe {
	const probe = changeSetProbes.get(node);
	if (probe === undefined)
		throw new Error(
			'webevm: changeSetsForTests() was handed an object createNode() did not return.',
		);
	return probe();
}

/**
 * Validate {@link NodeOptions.stateHistory}: ABSENT (`undefined`) is off and
 * returns `undefined`; `{blocks: N}` with N a positive safe integer returns N;
 * anything else throws.
 *
 * It composes with `computeStateRoot: true`: every node runs on the same flat state,
 * which is what the undo log records, and the derived trie only reads it. (It
 * was refused there while trie mode, as a root-computing node was then
 * called, ran on `MerkleStateManager`, which recorded
 * nothing; `trie-derived-from-the-flat-state` lifted that.)
 */
function validateStateHistory(options: NodeOptions): number | undefined {
	if (options.stateHistory === undefined) return undefined;
	const value = options.stateHistory as unknown;
	const blocks =
		typeof value === 'object' && value !== null
			? (value as {blocks?: unknown}).blocks
			: undefined;
	if (
		typeof blocks !== 'number' ||
		!Number.isSafeInteger(blocks) ||
		blocks <= 0
	)
		throw new Error(
			`webevm: stateHistory must be {blocks: N} with N a positive safe integer ` +
				`(how many blocks below the head stay readable), or absent for no history; ` +
				`got ${describeOption(value)}.`,
		);
	return blocks;
}

/**
 * Validate {@link NodeOptions.genesisTimestamp}: ABSENT (`undefined`) returns
 * `undefined` (block 0 takes the wall clock); a non-negative bigint returns
 * itself; anything else throws. A NUMBER is refused rather than converted, even
 * a whole one: every other timestamp the node takes (`blockEnv.timestamp`) is a
 * bigint, and accepting both would make the option mean two types.
 */
function validateGenesisTimestamp(options: NodeOptions): bigint | undefined {
	if (options.genesisTimestamp === undefined) return undefined;
	const value = options.genesisTimestamp as unknown;
	if (typeof value !== 'bigint' || value < 0n)
		throw new Error(
			`webevm: genesisTimestamp must be a non-negative bigint (seconds since the ` +
				`epoch, e.g. 1700000000n), or absent for the wall clock; got ` +
				`${typeof value === 'bigint' ? `${value}n` : `${describeOption(value)} (${typeof value})`}.`,
		);
	return value;
}

function describeOption(value: unknown): string {
	try {
		const s = JSON.stringify(value);
		return s === undefined ? String(value) : s;
	} catch {
		return String(value);
	}
}

export async function createNode(options: NodeOptions = {}): Promise<SlimNode> {
	return createNodeWithInternals(options, {});
}

/** {@link createNode} with {@link NodeInternals}; internal, see there. */
export async function createNodeWithInternals(
	options: NodeOptions,
	internals: NodeInternals,
): Promise<SlimNode> {
	const chainId = options.chainId ?? 31337;
	const senderMode: SenderMode = options.senderMode ?? 'recover';
	const miningConfig = options.miningConfig ?? {type: 'auto'};
	const baseFeePerGas = options.baseFeePerGas ?? 1_000_000_000n;
	const gasPrice = options.gasPrice ?? 1_000_000_000n;
	const maxPriorityFeePerGas = options.maxPriorityFeePerGas ?? 1_000_000_000n;
	const blockGasLimit = options.blockGasLimit ?? 30_000_000n;
	// Validated before anything is built, so a bad option costs nothing.
	const stateHistoryBlocks = validateStateHistory(options);
	const genesisTimestamp = validateGenesisTimestamp(options);
	/**
	 * `computeStateRoot: true`: derive a trie from the flat state, report its
	 * root. Only `true` turns it on (see {@link NodeOptions.computeStateRoot}).
	 */
	const computeStateRoot = options.computeStateRoot === true;

	const common = new Common({
		chain: {...Mainnet, chainId, name: 'webevm'},
		hardfork: Hardfork.Cancun,
		customCrypto: {keccak256: (m: Uint8Array) => keccak_256(m)},
	});

	// State backing, ONE for every node: our `SimpleStateManager` SUBCLASS, plain
	// Maps with no trie. Storage is per-account with per-checkpoint OVERLAYS
	// (upstream copies the whole flat storage map on every message frame), and it
	// implements the `clearStorage(address)` that upstream ships as an empty no-op,
	// without which a contract created at an address that already holds storage
	// inherits it. See ./state-manager.ts. `computeStateRoot` does NOT change it:
	// it adds a trie DERIVED from this state (`derivedTrie` below), which no engine
	// ever reads.
	const sm = new OverlayStorageStateManager();

	// THE CHANGE SET, switched on BEFORE the first write so that the construction
	// baselines below really go through the recorder and really get cleared when
	// genesis is stored (a baseline left in the record would reconstruct EMPTY
	// state at genesis). `changeSets` is the manager when recording, else
	// `undefined`, so every use below is one optional call.
	let changeSets: OverlayStorageStateManager | undefined;
	if (
		internals.recordChangeSets ||
		stateHistoryBlocks !== undefined ||
		computeStateRoot
	) {
		sm.enableChangeSets();
		changeSets = sm;
	}
	/**
	 * The change set of the HEAD block, taken from the open record when the block
	 * was mined. With `stateHistory` it is also the newest entry of {@link sealed};
	 * this slot is what the test probe reports as `headBlock`, with or without it.
	 */
	let headBlockChangeSet: ChangeSet | undefined;
	/**
	 * THE UNDO LOG (`stateHistory`): the SEALED change set of each of the last N
	 * mined blocks, oldest first. `sealed[i].changes` holds, for every key block
	 * `sealed[i].number` changed, the value it had at the END of the block before.
	 * Appended in `executeAndMine`, evicted there (anything at or below `head - N`
	 * serves no block in the window), and cleared by `loadState`. Always empty on a
	 * node without the option. See {@link historicalValue} for how a read uses it,
	 * and `docs/adr/0013-bounded-state-history-is-an-undo-log-over-the-flat-state.md`
	 * for why it is an undo log.
	 */
	const sealed: {number: number; changes: ChangeSet}[] = [];
	/**
	 * The oldest block whose state the undo log can reconstruct, WHATEVER the
	 * window: genesis at construction, the loaded head after `loadState` (a loaded
	 * dump is a baseline and carries no history). The window's oldest servable
	 * block is the later of this and `head - N`.
	 */
	let historyFloor = 0;
	/**
	 * Run a PURE READ (`eth_call`, `eth_estimateGas`, `eth_fillTransaction`'s
	 * estimate, with or without state overrides) with change-set recording
	 * suspended: every level it opens is reverted, so recording there is wasted
	 * work. A cost rule; see `withChangeSetsSuspended` in ./state-manager.ts.
	 */
	function pureRead<T>(read: () => Promise<T>): Promise<T> {
		return changeSets ? changeSets.withChangeSetsSuspended(read) : read();
	}

	/**
	 * THE SERIALISATION POINT: the tail of a promise chain that every public entry
	 * point queues its work onto, so this node runs exactly ONE piece of work at a
	 * time. It is declared HERE, beside `sm`, because the thing it protects is that
	 * object and nothing else.
	 *
	 * ## What was shared, and why it corrupts
	 *
	 * A state manager is a STACK of checkpoint levels. `checkpoint()` pushes a
	 * level, a write lands in the TOP one, `commit()` merges the top level into the
	 * one below and pops it, `revert()` pops it and throws it away. Neither
	 * `commit` nor `revert` knows WHO opened the level it is acting on — there is no
	 * handle, no owner and no identity — so the stack is only meaningful while a
	 * single execution owns it.
	 *
	 * Both halves of the node open levels on THIS one stack. `engine.transact`
	 * (`runTx`) checkpoints, executes and commits; the default engine's
	 * `engine.call` checkpoints and reverts, which is what makes an `eth_call` PURE
	 * and is a requirement of that EVM, not an option (see ./engine.ts). Both are
	 * `async` and `@ethereumjs/evm` yields to the microtask queue while it
	 * interprets, so before this existed a read arriving mid-transaction produced:
	 *
	 * ```
	 * tx   checkpoint   [base, tx]
	 * call checkpoint   [base, tx, call]   <- the read arrives mid-execution
	 * tx   write        -> lands in the TOP level, which is the CALL's
	 * tx   commit       -> merges that level down and pops it
	 * call revert       -> pops the merged level: the transaction's write is GONE
	 * ```
	 *
	 * Measured through this node's own RPC surface: a whole transaction lost (a
	 * plain transfer loses the sender's NONCE, so every later transaction from that
	 * account is refused as "nonce too high"), state TORN at a message-frame
	 * boundary (the EVM checkpoints per frame, so the read's level can land between
	 * an inner frame's checkpoint and its commit, leaving a state no execution could
	 * produce), an `eth_call`'s OWN write committed rather than reverted, and —
	 * because this is not about reads — two overlapping TRANSACTIONS losing a write
	 * the same way, both reporting success and both holding a receipt.
	 *
	 * ## Why the lock is HERE rather than around `engine.call`
	 *
	 * Because write-versus-write interleaves too, so a lock inside the read path
	 * would fix half of it. And because it must be INSIDE the node: the Worker
	 * transport forwards straight to `node.request` and comlink delivers
	 * concurrently, so a lock in a transport protects only consumers who use that
	 * transport. It is per NODE, which is per STATE MANAGER by construction —
	 * `createNode` builds its own `sm` and takes no state manager option, and an
	 * injected engine binds to the first node it is given to and refuses a second.
	 *
	 * ## Why EVERY request and not only the executing ones
	 *
	 * A read that never touches the EVM never checkpoints and so can never corrupt
	 * anything — but it reads the live stack INCLUDING uncommitted levels, so it
	 * reports a state no block contains. Measured, with a single transfer in flight:
	 * `eth_getBalance` saw the sender DEBITED from tick 5 and
	 * `eth_getTransactionCount` saw the nonce ADVANCED from tick 6, while
	 * `eth_blockNumber` still said 0 — and that reading is exactly what an
	 * overlapping `eth_call` could then destroy. The node's own block/receipt maps
	 * are written per-transaction inside the mining loop too, so a mid-execution
	 * `eth_getTransactionReceipt` can name a `blockHash` no lookup resolves yet.
	 * The cost is real and is stated in the ADR: a cheap read issued during a
	 * 209 ms `eth_estimateGas` search used to answer in 0.1 ms and now waits for it.
	 * A per-method exemption list was rejected because it is a promise that has to
	 * be re-proven every time a method is added, by somebody who will not know that
	 * is what they are doing.
	 *
	 * ## The shape
	 *
	 * `tail` is ALWAYS a promise that fulfils — the assignment below swallows both
	 * outcomes — so a failing request cannot poison the chain and cannot stop the
	 * queue behind it. Nothing inside the node re-enters a serialised entry point
	 * (the internal `request`, `mineBlock`, `dumpState`, `loadState` and
	 * `currentStateRoot` are all called directly, and only the returned object's
	 * members are wrapped), so a single chain cannot deadlock against itself.
	 *
	 * ## The one way a CONSUMER can deadlock it, and why it is NOT detected
	 *
	 * Control leaves the node twice while the chain is held, and both times into a
	 * consumer's code. They are not the same risk:
	 *
	 *  - an `onNewHead` callback is emitted WITHOUT being awaited, so a request it
	 *    issues queues behind the current one and runs when the chain drains. That
	 *    is the game-loop pattern (refetch on every head) and it is ALLOWED.
	 *  - a `persistence.save()` hook IS awaited — so that the dump it is handed is a
	 *    snapshot of a settled state and so that the request does not resolve before
	 *    the write is durable — which means a hook that AWAITS a call back into the
	 *    node waits for itself forever. That rule is documented, on
	 *    `PersistenceAdapter.save` where an adapter is written, and enforced nowhere.
	 *
	 * IT IS DELIBERATELY NOT ENFORCED, and this is the interesting part. The obvious
	 * guard — a flag raised around the awaited hook, with `serialise` refusing while
	 * it is set — WAS BUILT AND REMOVED, because it cannot work. The flag is held
	 * across the hook's I/O, the `await` yields the event loop for that whole
	 * duration, and JavaScript offers no way (no `AsyncLocalStorage` in a browser) to
	 * tell a request issued by the hook's own stack from one issued by anybody else
	 * in that window. Measured on a 20 ms save: a plain `setInterval` poller that had
	 * never heard of persistence got four rejections, each telling it that IT had
	 * caused a deadlock. A false refusal with a confident wrong diagnosis is worse
	 * than the hang it replaces, and it fires for every consumer who has persistence
	 * and a poller, which is this package's main use. So the honest arrangement is
	 * the one below: everyone queues, and the one pathological hook is a documented
	 * rule rather than a guess dressed as a check. See ADR 0012.
	 */
	let tail: Promise<void> = Promise.resolve();
	function serialise<T>(job: () => Promise<T>): Promise<T> {
		const run = tail.then(job);
		tail = run.then(swallow, swallow);
		return run;
	}

	/**
	 * THE DERIVED TRIE (`computeStateRoot: true` only; `undefined`, and never created,
	 * otherwise). Built from the WHOLE flat state once the genesis baselines are
	 * written and again at the end of `loadState`, and kept current from change
	 * sets by {@link currentStateRoot}. See ./derived-trie.ts.
	 */
	let derivedTrie: DerivedStateTrie | undefined;

	const ZERO_ROOT = ZERO_HASH;
	/**
	 * The state root of the flat state AS IT STANDS: the derived trie brought up
	 * to date with the OPEN RECORD (every key written since the head was mined)
	 * and its root read. Called at the end of each mined block, BEFORE the block's
	 * record is taken (so the block's own writes are in it), and by
	 * `getStateRoot()` for cheats since the head. Applying the open record twice
	 * (a `getStateRoot()`, then the block that includes the same writes) is
	 * harmless: the record only NAMES keys, and their values are re-read from the
	 * flat state each time. Both callers run inside the serialisation point with
	 * no checkpoint open, which the trie insists on. Without
	 * `computeStateRoot`: the zero placeholder, and no trie work at all.
	 */
	async function currentStateRoot(): Promise<string> {
		if (derivedTrie === undefined) return ZERO_ROOT;
		const open = sm.peekChangeSet();
		if (open !== undefined) await derivedTrie.apply(open);
		return hex(derivedTrie.root());
	}

	// Read-modify-write an account (creating an empty one if absent), used by the
	// evm_set* cheat methods.
	async function mutateAccount(
		addr: ReturnType<typeof createAddressFromString>,
		fn: (acc: Account) => void,
	): Promise<void> {
		const acc = (await sm.getAccount(addr)) ?? new Account();
		fn(acc);
		await sm.putAccount(addr, acc);
	}

	// Minimal mock blockchain: `runTx` (inside the default engine) only needs
	// getBlock (for BLOCKHASH) + shallowCopy. Without `computeStateRoot` we never
	// compute a canonical state root.
	const blockStore = new Map<number, StoredBlock>();
	const blockByHash = new Map<string, number>();
	const receipts = new Map<string, SerializedReceipt>();
	const transactions = new Map<string, SerializedTx>();
	let allLogs: SerializedLog[] = []; // flat, ordered log index for eth_getLogs

	const mockBlockchain: any = {
		getBlock: async (n: bigint | Uint8Array) => {
			let num: number;
			if (n instanceof Uint8Array) num = blockByHash.get(hex(n)) ?? 0;
			else num = Number(n);
			const sb = blockStore.get(num) ?? blockStore.get(latestNumber);
			return sb!.block;
		},
		putBlock: async () => {},
		shallowCopy() {
			return mockBlockchain;
		},
	};

	const vm: VM = await createVM({
		common,
		stateManager: sm,
		blockchain: mockBlockchain,
	});

	// THE ENGINE: what `eth_call` / `eth_estimateGas` / `eth_fillTransaction` read
	// on AND what the mining path executes transactions on. Default = this VM's own
	// `@ethereumjs/evm`, on both halves. An injected engine is connected HERE, during
	// construction, so an engine that cannot serve this node's configuration throws
	// now rather than at the first opcode.
	//
	// `??` is the ONLY place the default is chosen, and it reads an ABSENT option,
	// never a failure: an engine that was supplied and cannot come up fails the
	// construction (see connectEngine). There is deliberately no path from
	// "your engine did not work" to "here is a node on the default engine".
	//
	// ONE ENGINE, BOTH HALVES. There is no per-operation selection here and no
	// capability check: an `Engine` implements `call` AND `transact`, `connectEngine`
	// refuses one that does not, and `node.engine` therefore names the EVM that
	// answered this node's reads and executed its transactions alike.
	const engine: Engine =
		options.engine ?? createEthereumjsEngine({vm, stateManager: sm});
	await connectEngine(engine, {
		stateManager: sm,
		common,
		// Block hashes for BLOCKHASH, read LIVE (no block exists yet at this point)
		// and SYNCHRONOUSLY, because an engine answers BLOCKHASH mid-opcode.
		getBlockHash: (blockNumber: bigint) => {
			const sb = blockStore.get(Number(blockNumber));
			return sb ? hexToBytes(sb.header.hash as `0x${string}`) : undefined;
		},
	});

	// THE ENGINE'S secp256k1, IF IT BROUGHT ONE. Read ONCE, after `connect`, so a
	// transaction never pays a property lookup and — more to the point — so which
	// implementation recovers this node's senders is fixed for the node's lifetime
	// rather than able to change under it. `undefined` means the node recovers the
	// way it always did (`tx.getSenderAddress()`); it is NOT filled in with a
	// default, because the fallback IS `@ethereumjs/tx`'s own recovery and wrapping
	// it as an engine method would only add a layer. See ./sender-recovery.ts.
	const engineEcrecover =
		typeof engine.ecrecover === 'function'
			? engine.ecrecover.bind(engine)
			: undefined;

	let latestNumber = 0;
	let parentHash = hexToBytes(ZERO_HASH);

	// Initial balances FIRST (so the genesis state root, when computed, reflects them).
	if (options.initialBalances) {
		for (const [addr, bal] of Object.entries(options.initialBalances)) {
			await sm.putAccount(createAddressFromString(addr), new Account(0n, bal));
		}
	}
	// Full genesis pre-state (balance/nonce/code/storage) — e.g. a GeneralStateTest
	// `pre` section. Applied before block 0 so a computed genesis root reflects
	// it and a post-tx getStateRoot() can be compared to the fixture's hash.
	if (options.initialState) {
		for (const [addr, acc] of Object.entries(options.initialState)) {
			const address = createAddressFromString(addr);
			await sm.putAccount(
				address,
				new Account(acc.nonce ?? 0n, acc.balance ?? 0n),
			);
			if (acc.code && acc.code !== '0x')
				await sm.putCode(address, hexToBytes(acc.code));
			for (const [slot, val] of Object.entries(acc.storage ?? {})) {
				await sm.putStorage(
					address,
					setLengthLeft(bigIntToBytes(BigInt(slot)), 32),
					hexToBytes(val),
				);
			}
		}
	}
	// THE TRIE IS BUILT FROM THE FULL FLAT STATE, here, once: the baselines above
	// are block 0 and deliberately in NO change set (the record is cleared just
	// after genesis is stored), so a trie kept from change sets alone would omit
	// them and every genesis-dependent root would be wrong.
	if (computeStateRoot) derivedTrie = await DerivedStateTrie.build(sm, common);

	const blockEnv = options.blockEnv;

	/**
	 * THE GAS LIMIT OF EVERY BLOCK THIS NODE BUILDS, named once so that the block
	 * builder and the check that refuses a transaction too large for it cannot
	 * drift apart. `blockEnv.gasLimit` is the explicit per-block statement and
	 * `blockGasLimit` the node-wide one, in that order, which is the precedence the
	 * header below uses, because they are the same number.
	 *
	 * IT IS A REAL LIMIT, NOT A FORMALITY. The node used to hand `@ethereumjs/vm`
	 * a `skipBlockGasLimitValidation`, so a transaction asking for more gas than
	 * the block had was mined anyway, against a limit the block did not have, and
	 * only on that engine (revm expresses the same relaxation as a simulation
	 * switch and refuses to combine any of them with committing, so it rejected the
	 * very same transaction with `CallerGasLimitMoreThanBlock`). The flag is gone.
	 * A consumer who wants enormous gas limits raises `blockGasLimit`, which makes
	 * the permissiveness a VISIBLE property of the block that both engines honour
	 * by construction, and an honest one, since `GASLIMIT` then reports that same
	 * number to a contract.
	 */
	const minedBlockGasLimit = blockEnv?.gasLimit ?? blockGasLimit;

	// Genesis block.
	//
	// IT TAKES `blockEnv`'s COINBASE AND PREVRANDAO, and nothing else from it. Those
	// two describe the environment this CHAIN runs under, so a block 0 reporting a
	// zero miner while every block after it reports the configured one would be the
	// same RPC-vs-EVM disagreement the fields are stored to remove, one block wide.
	// `number`, `timestamp` and `gasLimit` stay the node's own: genesis IS block 0,
	// and `blockEnv.number` places a MINED block rather than renumbering the chain's
	// genesis (`minedBlockGasLimit` above is likewise the MINED block's limit).
	// Its timestamp is `genesisTimestamp` when given, else the wall clock: a
	// separate option rather than `blockEnv.timestamp`, which pins every MINED
	// block to one value and so cannot also be block 0's (see the option's JSDoc).
	const genesis = createBlock(
		{
			header: {
				number: 0n,
				gasLimit: blockGasLimit,
				baseFeePerGas,
				timestamp: genesisTimestamp ?? BigInt(Math.floor(Date.now() / 1000)),
				...(blockEnv?.coinbase
					? {coinbase: createAddressFromString(blockEnv.coinbase)}
					: {}),
				difficulty: 0n,
				...(blockEnv?.prevRandao
					? {mixHash: hexToBytes(blockEnv.prevRandao)}
					: {}),
			},
		},
		{common},
	);
	storeBlock(genesis, [], [], await currentStateRoot());
	// BASELINES ARE NOT HISTORY: `initialBalances` / `initialState` ARE block 0,
	// not a change to it.
	changeSets?.takeChangeSet();

	// Pending raw txs awaiting the next mined block (manual/interval modes). Each
	// carries its SENDER, decided once at parse time by `parseTx`: the node derives
	// the sender (or is told it), never the engine.
	const pending: SubmittedTx[] = [];

	// newHeads subscribers.
	const headSubs = new Set<(h: {number: number; hash: string}) => void>();
	// Ports `serveOn` is serving, so `dispose` can stop them all.
	const servedPorts = new Set<ServedProvider>();

	// THE INTERVAL TIMER IS ARMED AT THE BOTTOM OF THIS FUNCTION, not here, at the
	// `miningConfig.type === 'interval'` block just above the `return`. The reason
	// is ordering: a timer armed at this point can fire while the
	// REST OF CONSTRUCTION is still running, and the construction-time
	// `loadState(saved)` that the persistence option performs is deliberately not
	// serialised (nothing can reach the node yet, because it has not been returned).
	// Those two together are the one interleaving the serialisation point does not
	// cover, so the timer starts after the node is fully built instead.
	let intervalTimer: ReturnType<typeof setInterval> | undefined;

	/**
	 * THE NODE'S CLOCK: the timestamp a mined block is stamped with, and the time
	 * cheats that move it (`evm_setNextBlockTimestamp`, `evm_increaseTime`,
	 * `evm_setBlockTimestampInterval` / `evm_removeBlockTimestampInterval`, and
	 * `evm_mine`'s optional timestamp).
	 *
	 * WITH NO CHEAT ISSUED IT IS EXACTLY WHAT IT WAS: `blockEnv.timestamp` when
	 * pinned, else the wall clock in whole seconds, with no reference to the parent.
	 * Whether that default should become strictly increasing is a separate question
	 * (work/notes/observations/2026-09-28-mined-block-timestamps-are-not-strictly-increasing.md)
	 * which this does not decide. A block reads the cheats in this order:
	 *
	 *   1. a NEXT TIMESTAMP, set once and used by the next block mined; it must be
	 *      later than the head's, and once a block carries it the OFFSET moves so
	 *      that the clock carries on from there (anvil's and hardhat's behaviour);
	 *   2. an INTERVAL: the parent's timestamp plus this many seconds, the wall
	 *      clock not consulted, so a chain's timestamps do not depend on when or how
	 *      fast it ran (anvil's `anvil_setBlockTimestampInterval`);
	 *   3. the BASE (`blockEnv.timestamp`, else the wall clock) plus the OFFSET,
	 *      which `evm_increaseTime` adds to.
	 *
	 * NODE SETTINGS, NOT CHAIN STATE: none of it is in `dumpState`. `loadState`
	 * clears a pending next timestamp (the loaded head may already be past it);
	 * the offset and the interval belong to this node and survive it.
	 */
	let nextTimestamp: bigint | undefined;
	let timeOffset = 0n;
	let timestampInterval: bigint | undefined;
	const clockBase = () =>
		blockEnv?.timestamp ?? BigInt(Math.floor(Date.now() / 1000));
	const headTimestamp = () =>
		blockStore.get(latestNumber)?.block.header.timestamp ?? 0n;
	function plannedTimestamp(): bigint {
		if (nextTimestamp !== undefined) return nextTimestamp;
		if (timestampInterval !== undefined)
			return headTimestamp() + timestampInterval;
		return clockBase() + timeOffset;
	}

	/**
	 * A time cheat's seconds: a non-negative integer, as a JSON number or a
	 * quantity string (hex `0x…` or decimal). Anything else is `-32602`, naming
	 * the method, rather than a guess.
	 */
	function seconds(value: unknown, method: string): bigint {
		let s: bigint | undefined;
		if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0)
			s = BigInt(value);
		else if (
			typeof value === 'string' &&
			(/^0x[0-9a-fA-F]+$/.test(value) || /^[0-9]+$/.test(value))
		)
			s = BigInt(value);
		if (s === undefined)
			throw new RpcError(
				-32602,
				`${method}: expected a non-negative integer number of seconds, got ${JSON.stringify(value)}`,
			);
		return s;
	}

	/** A next timestamp must be later than the head's: post-Merge blocks are. */
	function laterThanHead(value: unknown, method: string): bigint {
		const t = seconds(value, method);
		const head = headTimestamp();
		if (t <= head)
			throw new RpcError(
				-32000,
				`${method}: timestamp ${t} is not later than the head block's timestamp ${head}`,
			);
		return t;
	}

	/**
	 * THE BLOCK'S LOGS BLOOM: the OR of its receipts' own blooms, which is what a
	 * block bloom IS. Derived here rather than carried out of the mining loop so
	 * that `loadState` can rebuild it for a dump written before `SerializedBlock`
	 * had the field — same function, same answer, both sides of a round trip.
	 *
	 * IT IS NOT READ OFF `block.header.logsBloom`, unlike the coinbase and the
	 * mixHash beside it in `storeBlock`: the header is built (and frozen) BEFORE the
	 * block's transactions execute, so the only truthful bloom is this one.
	 */
	function bloomOfReceipts(txHashes: string[]): string {
		const acc = new Uint8Array(256);
		for (const h of txHashes) {
			const r = receipts.get(h);
			if (!r) continue;
			const bits = hexToBytes(r.logsBloom);
			for (let i = 0; i < acc.length && i < bits.length; i++) acc[i] |= bits[i];
		}
		return hex(acc);
	}

	function storeBlock(
		block: Block,
		txHashes: string[],
		logs: SerializedLog[],
		stateRoot: string,
	) {
		const number = Number(block.header.number);
		const hash = hex(block.hash());
		const header: SerializedBlock = {
			number,
			hash,
			parentHash: hex(block.header.parentHash),
			timestamp: Number(block.header.timestamp),
			gasUsed: numHex(block.header.gasUsed),
			gasLimit: numHex(block.header.gasLimit),
			baseFeePerGas: numHex(block.header.baseFeePerGas ?? baseFeePerGas),
			stateRoot,
			// THE BLOCK'S OWN COINBASE AND MIXHASH, PERSISTED. They are read off the
			// `Block` the EVM just ran — not off `blockEnv` — so "what the RPC reports"
			// and "what COINBASE / PREVRANDAO returned" are one value with one source,
			// and they are stored HERE because `loadState` rebuilds the block from this
			// record: a reader that went to `sb.block` would answer correctly until a
			// reload and zero afterwards.
			miner: block.header.coinbase.toString(),
			mixHash: hex(block.header.mixHash),
			logsBloom: bloomOfReceipts(txHashes),
			transactions: txHashes,
			logsCount: logs.length,
		};
		blockStore.set(number, {block, header, logs});
		blockByHash.set(hash, number);
		latestNumber = number;
		parentHash = block.hash();
	}

	async function executeAndMine(
		txs: SubmittedTx[],
	): Promise<{blockNumber: number; blockHash: string; txHashes: string[]}> {
		const number = blockEnv?.number ?? BigInt(latestNumber + 1);
		const blockBaseFee = blockEnv?.baseFeePerGas ?? baseFeePerGas;
		// THE NODE'S CLOCK (above): unchanged from the wall clock or
		// `blockEnv.timestamp` until a time cheat is issued. A next timestamp is
		// spent only once the block is stored, so a refused transaction leaves it
		// for the block that does get mined.
		const timestamp = plannedTimestamp();
		const spendsNextTimestamp = nextTimestamp !== undefined;
		const block = createBlock(
			{
				header: {
					number,
					gasLimit: minedBlockGasLimit,
					baseFeePerGas: blockBaseFee,
					parentHash,
					timestamp,
					...(blockEnv?.coinbase
						? {coinbase: createAddressFromString(blockEnv.coinbase)}
						: {}),
					// post-Merge: difficulty must be 0; prevRandao lives in mixHash.
					difficulty: 0n,
					...(blockEnv?.prevRandao
						? {mixHash: hexToBytes(blockEnv.prevRandao)}
						: {}),
				},
			},
			{common},
		);
		const blockHash = hex(block.hash());
		const blockNumber = Number(number);

		const txHashes: string[] = [];
		const blockLogs: SerializedLog[] = [];
		let cumulativeGasUsed = 0n;
		let txIndex = 0;

		for (const {tx, raw, sender} of txs) {
			// THE MINING PATH GOES THROUGH THE ENGINE. What comes back is the neutral
			// `TransactionResult` — everything a receipt needs from an EVM and nothing
			// else — so every line below is the NODE's own half: the block it landed in,
			// the running `cumulativeGasUsed`, log positions, and the receipt itself.
			// THE SENDER IS PASSED, NOT LEFT TO BE FOUND. It is the node's own value
			// (recovered, or claimed in `senderMode:'trusted'`), and the receipt's `from`
			// below is the SAME value — so "who the engine executed as" and "who the
			// receipt names" cannot drift apart by engine.
			//
			// ...AND WHETHER IT MAY SEND IT AT ALL IS ANSWERED FIRST, HERE, against the
			// state this transaction is about to run on and in the node's own words, so
			// that a replayed, unaffordable or unreachable-nonce transaction is refused
			// identically on every engine instead of in whichever vocabulary the
			// installed one happens to speak. Nothing has been committed for this
			// transaction when it throws: no receipt is built, no log is recorded, and
			// the block below is never stored.
			await refuseIfSenderCannotSend(tx, sender);
			const res = await engine.transact({tx, sender, block});
			cumulativeGasUsed += res.gasUsed;
			const h = txHashOf(tx);
			const from = sender.toString();
			const to = (tx as any).to ? (tx as any).to.toString() : null;
			const created = res.createdAddress ? hex(res.createdAddress) : null;
			const rcptLogs: SerializedLog[] = res.logs.map((log, i) => {
				const sl: SerializedLog = {
					address: hex(log.address),
					topics: log.topics.map((t) => hex(t)),
					data: hex(log.data),
					blockNumber,
					blockHash,
					transactionHash: h,
					transactionIndex: txIndex,
					logIndex: blockLogs.length + i,
				};
				return sl;
			});
			blockLogs.push(...rcptLogs);

			const receipt: SerializedReceipt = {
				transactionHash: h,
				transactionIndex: txIndex,
				blockNumber,
				blockHash,
				from,
				to,
				contractAddress: created,
				cumulativeGasUsed: numHex(cumulativeGasUsed),
				gasUsed: numHex(res.gasUsed),
				effectiveGasPrice: numHex(res.effectiveGasPrice),
				status: res.status,
				type: (tx as any).type ?? 0,
				logs: rcptLogs,
				logsBloom: hex(res.logsBloom),
			};
			receipts.set(h, receipt);

			const stx: SerializedTx = {
				hash: h,
				raw: hex(raw),
				from,
				to,
				nonce: Number((tx as any).nonce),
				value: numHex((tx as any).value ?? 0n),
				input: hex((tx as any).data ?? new Uint8Array()),
				type: (tx as any).type ?? 0,
				blockNumber,
				blockHash,
				transactionIndex: txIndex,
				gas: numHex((tx as any).gasLimit),
				gasPrice:
					(tx as any).gasPrice !== undefined
						? numHex((tx as any).gasPrice)
						: null,
				maxFeePerGas:
					(tx as any).maxFeePerGas !== undefined
						? numHex((tx as any).maxFeePerGas)
						: null,
				maxPriorityFeePerGas:
					(tx as any).maxPriorityFeePerGas !== undefined
						? numHex((tx as any).maxPriorityFeePerGas)
						: null,
			};
			transactions.set(h, stx);
			txHashes.push(h);
			txIndex++;
		}

		allLogs.push(...blockLogs);
		// The root BEFORE the record is taken below: `currentStateRoot` applies the
		// open record, which at this point is exactly what this block changed.
		storeBlock(block, txHashes, blockLogs, await currentStateRoot());
		if (spendsNextTimestamp) {
			nextTimestamp = undefined;
			timeOffset = timestamp - clockBase();
		}
		// THE BLOCK'S CHANGE SET is everything written since the previous head was
		// mined: this block's transactions AND any `evm_set*` cheat issued between
		// the two blocks, which belongs to this block (the first one that can see
		// it). Taken with no checkpoint open, which `takeChangeSet` insists on.
		if (changeSets) headBlockChangeSet = changeSets.takeChangeSet();
		if (stateHistoryBlocks !== undefined && headBlockChangeSet !== undefined)
			sealBlock(blockNumber, headBlockChangeSet, stateHistoryBlocks);
		// emit newHeads
		for (const cb of headSubs) cb({number: blockNumber, hash: blockHash});

		return {blockNumber, blockHash, txHashes};
	}

	/**
	 * SEAL the change set just taken as block `number`'s undo record, and EVICT
	 * every record at or below `head - N`: a read at the oldest servable block
	 * `head - N` needs the records of blocks `head - N + 1 .. head` and no other,
	 * so exactly N are kept.
	 *
	 * A block MINED UNDER THE SAME NUMBER as the newest record (a fixed
	 * `blockEnv.number` does that: every mined block replaces the head) is MERGED
	 * into it, the older entry winning, as a checkpoint commit merges: the merged
	 * record then holds each key's value from before the first of them, which is
	 * what a read below that number needs, and the log stays bounded.
	 */
	function sealBlock(number: number, changes: ChangeSet, window: number): void {
		const newest = sealed[sealed.length - 1];
		if (newest !== undefined && newest.number === number)
			mergeChangeSetOlderWins(newest.changes, changes);
		else sealed.push({number, changes});
		const oldestKept = latestNumber - window;
		let drop = 0;
		while (drop < sealed.length && sealed[drop].number <= oldestKept) drop++;
		if (drop > 0) sealed.splice(0, drop);
	}

	async function mineBlock() {
		const batch = pending.splice(0, pending.length);
		return executeAndMine(batch);
	}

	/**
	 * Decode a raw tx AND DECIDE ITS SENDER, once. When `claimedFrom` is supplied
	 * (the `evm_*As` methods, `senderMode:'trusted'` only) we SKIP ecrecover and take
	 * the caller-supplied address as the sender; otherwise we recover it, as a real
	 * node does.
	 *
	 * THE SENDER IS A VALUE FROM HERE ON. It travels with the transaction (see
	 * {@link SubmittedTx}) to the receipt's `from` and across the engine seam as
	 * `TransactionRequest.sender`, so exactly ONE place in the node answers "who sent
	 * this" and no engine is trusted to answer it again. Recovery is therefore EAGER
	 * (at submit, not at mine): a transaction whose signature cannot be recovered is
	 * rejected by the `eth_sendRawTransaction*` call that submitted it rather than by
	 * a later `mine()`, which is where a `'recover'` node would have failed anyway.
	 *
	 * WHAT THIS PRIMITIVE IS: "execute this tx as this sender, do not recover".
	 * That is all. It is deliberately NOT an impersonation feature — impersonation
	 * (an address registry + unsigned `eth_sendTransaction`, anvil/hardhat style) is
	 * account POLICY, and this package has no accounts by design. Two DIFFERENT
	 * callers want this one primitive:
	 *
	 *   (a) A NORMAL, genuinely-signed tx that just wants to bypass a redundant
	 *       ecrecover. The client signed it, so it already knows the sender;
	 *       re-deriving it on a local chain is pure waste. The signature is REAL,
	 *       merely unverified.
	 *   (b) A HIGHER LAYER implementing impersonation on top: it has no key, so it
	 *       FABRICATES a signature, serialises the tx, and passes the claimed
	 *       sender. Nothing here needs to know that happened.
	 *
	 * WHY it is worth a cheat method: ecrecover is a FIXED cost per tx and it is the
	 * single dominant cost of a small one. Measured 2026-08-11
	 * (`docs/spikes/sender-recovery-uses-the-engines-ecrecover/measurements.md`) at
	 * ~6.2x on the isolated transaction path (2.09 -> 0.33 ms/tx, signing outside the
	 * window) and ~3.6x end-to-end through a viem-style client (2.37 -> 0.66 ms/tx;
	 * the residual is the CLIENT's own signing, which only case (b) avoids). Gas and
	 * status are byte-identical either way.
	 *
	 * THE GAP DEPENDS ON THE ENGINE NOW, and it has NARROWED. With an engine that
	 * brings its own secp256k1 (`Engine.ecrecover` in ./types.ts —
	 * `webevm/revm` does, at zero additional bytes) the recovery itself is
	 * ~4.3x cheaper, so `'recover'` costs 0.65 ms/tx isolated instead of 2.02 and the
	 * ratio falls to ~2.8x (~1.8x end to end). It stays worth having; it has stopped
	 * being the dominant lever. The figures this paragraph used to carry (~13x, ~2.3x)
	 * were measured on `runTx` in isolation before the storage re-layer of ADR 0009,
	 * and had drifted by roughly half — not because recovery got slower, but because
	 * everything around it got faster.
	 *
	 * HOW: the claimed address becomes this transaction's sender, full stop — nothing
	 * on the transaction is touched. Everything else about it stays REAL — same wire
	 * bytes, same `tx.hash()`, same signature on the wire — so receipts, block
	 * contents and `eth_getTransactionByHash` are unchanged. The ONLY thing dropped is
	 * the proof that the signer authorised this sender.
	 *
	 * IT USED TO SHADOW `tx.getSenderAddress()` on the parsed instance, because
	 * `runTx` reads the sender through exactly that one call. That worked only while
	 * the node itself ran `runTx`: once transactions cross the engine seam, a pinned
	 * method is an undocumented convention an engine has to interrogate the same way,
	 * and an engine recovering its own sender would silently execute as the SIGNER —
	 * charging that account, advancing its nonce, returning a plausible receipt. So
	 * the sender is data now, and the shadowing is gone rather than kept as a second
	 * mechanism saying the same thing.
	 *
	 * ---- CALLER CONTRACT, case (b) / fabricated signatures ONLY ----
	 *
	 * 1. TX BYTES MUST BE UNIQUE PER SENDER. `from` is NOT part of a transaction —
	 *    it is the OUTPUT of recovery — so the hash is computed from the bytes
	 *    alone. Two fabricated txs with the same dummy signature, nonce, `to` and
	 *    data produce the SAME hash even for different claimed senders, and would
	 *    silently overwrite each other in the receipt/tx maps. Derive the dummy `r`
	 *    from the sender address (or otherwise vary the bytes per sender). anvil hit
	 *    exactly this and fixed it by folding the sender into hash computation
	 *    (foundry #4210). Genuinely-signed txs — case (a) — are unaffected: real
	 *    signatures already differ per signer.
	 *
	 * 2. FABRICATED TXS ARE NOT PORTABLE TO A `'recover'` NODE. `dumpState` stores
	 *    each tx's raw bytes, so a dump containing fabricated signatures carries txs
	 *    no authenticated node could ever validate. Fine for a local chain; do not
	 *    treat such a dump as a replayable chain history. Again, case (a) dumps are
	 *    unaffected — those signatures are real.
	 *
	 * SAFETY: gated on `senderMode:'trusted'`. In the default `'recover'` mode these
	 * methods do not exist and we throw -32601 rather than silently trusting input.
	 */
	function parseTx(rawHex: unknown, claimedFrom?: unknown): SubmittedTx {
		const raw = hexToBytes(String(rawHex));
		if (claimedFrom === undefined) {
			const tx = createTxFromRLP(raw, {common});
			// THE CURVE STEP, ON THE ENGINE WHEN THE ENGINE HAS ONE. The DECISION
			// (which message is signed, EIP-2's low-`s` rule, what the wire's `v`
			// means) stays here either way — see ./sender-recovery.ts, and
			// `Engine.ecrecover` in ./types.ts for why it is the seam's one optional
			// operation. With no engine ecrecover this is `@ethereumjs/tx`'s own
			// recovery, unchanged, and the two are proven to authenticate identically
			// (test/helpers/sender-recovery.ts) — on the transactions they ACCEPT and
			// on the ones they must REFUSE.
			return {
				tx,
				raw,
				sender: engineEcrecover
					? recoverSender(tx, common, engineEcrecover)
					: tx.getSenderAddress(),
			};
		}
		if (senderMode !== 'trusted') {
			throw new RpcError(
				-32601,
				"method not available: trusted-sender sends require senderMode:'trusted' " +
					'(create the node with {senderMode:"trusted"} to skip ecrecover). That mode ' +
					'TRUSTS the caller-supplied sender, so ANY caller can impersonate ANY ' +
					'address — never enable it where untrusted callers can reach the node.',
			);
		}
		// Throws on a malformed address rather than executing as someone unexpected.
		const from = createAddressFromString(String(claimedFrom));
		// The transaction is parsed FROZEN, like every other one: nothing about it is
		// rewritten to carry the claimed sender, because the sender does not live on it.
		const tx = createTxFromRLP(raw, {common});
		return {tx, raw, sender: from};
	}

	/**
	 * REFUSE A TRANSACTION NO BLOCK THIS NODE BUILDS COULD CONTAIN, in the node's
	 * own words, before any engine sees it.
	 *
	 * WHY THE NODE SAYS IT AND NOT THE ENGINE. Both engines enforce this rule
	 * themselves now that the default engine no longer skips it (see ./engine.ts),
	 * and NEITHER can say it legibly: `@ethereumjs/vm` says "tx has a higher gas
	 * limit than the block" and revm says `Transaction(CallerGasLimitMoreThanBlock)`.
	 * Neither carries a number, and above all neither mentions `blockGasLimit`, the
	 * knob that lifts it, which only the node knows about. The block is the NODE's
	 * half of the seam on every engine (it builds it, it configures its gas limit),
	 * so "does this transaction fit in a block I will build" is the node's question
	 * to answer, and answering it here is what makes the refusal IDENTICAL on both
	 * engines rather than merely present on both. The engines' own checks stay as
	 * the backstop underneath: this is the same rule (`tx.gasLimit >
	 * block.header.gasLimit`, per transaction, not cumulative), so a transaction
	 * that passes here passes there.
	 *
	 * WHY AT SUBMIT rather than at mine: the same reason sender recovery is eager
	 * (see {@link parseTx}). The transaction is rejected by the
	 * `eth_sendRawTransaction*` call that submitted it, rather than sitting in
	 * `pending` and taking a whole later `mine()` batch down with it. Nothing about
	 * the answer changes with time: every block this node builds has the same
	 * {@link minedBlockGasLimit}.
	 */
	function refuseIfOverBlockGasLimit(tx: TypedTransaction): void {
		const gasLimit = (tx as any).gasLimit as bigint;
		if (gasLimit <= minedBlockGasLimit) return;
		// -32000 (the JSON-RPC server-error range geth uses for a transaction its
		// pool refuses) rather than 3 `execution reverted`: nothing executed, and a
		// client that reads a revert here would look for return data that does not
		// exist.
		throw new RpcError(
			-32000,
			`transaction gas limit ${gasLimit} exceeds the block gas limit ${minedBlockGasLimit}, so no block this node builds could contain it. ` +
				`It is REFUSED rather than mined against a limit the block does not have (a real node refuses it too, and this node's other EVM engine always did). ` +
				`To allow it, raise the limit: createNode({blockGasLimit: ${gasLimit}n}). The default is 30000000n, or blockEnv.gasLimit if you set the block environment explicitly. ` +
				`The block then really is that large: GASLIMIT reports the configured value to a contract, and eth_getBlockByNumber reports it too.`,
		);
	}

	/**
	 * REFUSE A TRANSACTION THE SENDER'S OWN ACCOUNT FORBIDS — a replay, a nonce this
	 * node will never reach, or a bill the sender cannot cover — in the node's own
	 * words, before the engine sees it.
	 *
	 * WHY THE NODE SAYS IT AND NOT THE ENGINE, which is the same argument
	 * {@link refuseIfOverBlockGasLimit} makes and the reason this sits beside it.
	 * Both engines enforce these three rules already, and neither can say them in a
	 * way a client can use: `@ethereumjs/vm` answers a replay with `the tx doesn't
	 * have the correct nonce. account has nonce of: 1 tx has nonce of: 0` followed
	 * by a dump of the whole block and transaction, and revm answers it with
	 * `Transaction(NonceTooLow { tx: 0, state: 1 })`. Same node, same transaction,
	 * two unrelated sentences — and the revm one is a wasm-shaped string arriving
	 * where a client expects prose, the transaction-path twin of the mistake
	 * recorded in the `rejectionMessage` JSDoc of ./revm.ts. The node owns the
	 * STATE on every engine (ADR 0010) and it owns the transaction's parsing, so
	 * "may this sender send this transaction now" is the node's question, and
	 * answering it here is what makes the refusal IDENTICAL across engines rather
	 * than merely present on both. The engines' own checks stay as the backstop
	 * underneath: these are the same three rules, so a transaction that passes here
	 * passes there.
	 *
	 * IT ALSO FIXES THE ORDER, which no engine agrees about: a transaction that is
	 * both replayed and unaffordable is reported as a nonce failure by geth and by
	 * this node, and could be reported as either by an engine. One order here means
	 * one answer whatever is installed.
	 *
	 * WHY AT MINE-TIME rather than at submit, unlike its two siblings: these answers
	 * CHANGE WITH TIME. In `manual`/`interval` mining a consumer submits nonce 0 and
	 * nonce 1 back to back, and at submit the second is a nonce this node has not
	 * reached; by the time the batch is mined, the first has advanced it. The same
	 * goes for the money. So the reading is taken at the last possible moment —
	 * immediately before the engine would execute it — against the state the
	 * transaction is actually about to run on.
	 *
	 * THE VOCABULARY IS geth's leading clause (`nonce too low` / `nonce too high` /
	 * `insufficient funds for gas * price + value`), because a client already knows
	 * it: viem maps those phrases onto typed errors. Inventing a private dialect for
	 * rules the whole ecosystem already names would cost every consumer a
	 * translation and buy nothing. What follows the clause is this node's own
	 * honest-edge half — what happened and what to do about it — including the one
	 * thing a real node would NOT say: that there is no mempool here, so a
	 * too-high nonce is refused rather than queued.
	 */
	async function refuseIfSenderCannotSend(
		tx: TypedTransaction,
		sender: Address,
	): Promise<void> {
		// ONE READ of the sender's account, for both rules: a missing account is a
		// sender at nonce 0 holding nothing, which is exactly how every other read on
		// this node reports it (`eth_getTransactionCount`, `eth_getBalance`).
		const account = await sm.getAccount(sender);
		const stateNonce = account?.nonce ?? 0n;
		const txNonce = tx.nonce;
		const address = sender.toString();
		if (txNonce < stateNonce) {
			throw new RpcError(
				-32000,
				`nonce too low: address ${address}, tx: ${txNonce}, state: ${stateNonce}. ` +
					`The sender has already used that nonce, so this transaction is a REPLAY ` +
					`and is REFUSED rather than mined a second time. Sign it again with nonce ` +
					`${stateNonce} — eth_getTransactionCount reports the sender's next nonce.`,
			);
		}
		if (txNonce > stateNonce) {
			throw new RpcError(
				-32000,
				`nonce too high: address ${address}, tx: ${txNonce}, state: ${stateNonce}. ` +
					`This node has NO MEMPOOL, so a transaction that is not executable NOW is ` +
					`refused rather than queued until the gap is filled: waiting will not mine ` +
					`it. Send the missing transactions first, or sign this one with nonce ` +
					`${stateNonce} — eth_getTransactionCount reports the sender's next nonce.`,
			);
		}
		const balance = account?.balance ?? 0n;
		const upfront = upfrontCost(tx);
		if (balance < upfront) {
			throw new RpcError(
				-32000,
				`insufficient funds for gas * price + value: address ${address} have ` +
					`${balance} want ${upfront}. The sender must be able to pay for its WHOLE ` +
					`gas limit at the maximum fee it offered, plus the value it sends, BEFORE ` +
					`the transaction runs — even though it is charged less than that once the ` +
					`gas it really used is known. Lower the value, the gas limit or ` +
					`maxFeePerGas, or fund the sender.`,
			);
		}
	}

	/**
	 * REFUSE A TRANSACTION THAT COULD NOT REACH ITS FIRST OPCODE, in the node's own
	 * words, before any engine sees it.
	 *
	 * The second of the two refusals a transaction earns ON ITS OWN, which is why it
	 * sits beside {@link refuseIfOverBlockGasLimit} and at the same moment: both
	 * read the transaction and nothing else, so neither answer can change while the
	 * transaction waits in `pending`, and refusing eagerly means the
	 * `eth_sendRawTransaction*` call that submitted it is the one that fails. The
	 * two that DO depend on the chain's state — the nonce and the money — are
	 * checked at the last possible moment instead, in {@link refuseIfSenderCannotSend}.
	 *
	 * THE FLOOR IS THE TRANSACTION'S OWN `getIntrinsicGas()`, NOT the shared
	 * `intrinsicGas()` of ./intrinsic-gas.ts, and the difference is load-bearing:
	 * the shared formula has no ACCESS-LIST term, because an `eth_call` carries no
	 * access list, so it is 6,200 gas short for a type-1 transaction naming one
	 * address and two keys. Both engines charge the access list, so a check built on
	 * the shared formula would wave such a transaction through and let the engine
	 * refuse it in its own vocabulary — the exact divergence this refusal exists to
	 * remove. Measured, on four transaction shapes and against BOTH engines' actual
	 * floors, in
	 * `docs/spikes/replayed-and-invalid-transactions-are-rejected-as-the-nodes-own-errors/measurements.md`.
	 * The two figures answer two different questions and both are the node's: what a
	 * READ must be budgeted (and an engine's execution gas topped up by), versus what
	 * a TRANSACTION must be able to pay before it starts.
	 */
	function refuseIfBelowIntrinsicGas(tx: TypedTransaction): void {
		const gasLimit = tx.gasLimit;
		const minimum = tx.getIntrinsicGas();
		if (gasLimit >= minimum) return;
		throw new RpcError(
			-32000,
			`intrinsic gas too low: have ${gasLimit}, want ${minimum}. ` +
				`A transaction pays a 21000 base plus its calldata (and its access list, and ` +
				`32000 more to create a contract) before its first opcode runs, so this gas ` +
				`limit could not start it and no block this node builds could contain it. ` +
				`Raise the gas limit to at least ${minimum} — eth_estimateGas reports what a ` +
				`transaction needs, given the same calldata AND the same access list, which ` +
				`it charges too.`,
		);
	}

	/** Queue-or-execute a submitted tx; returns the hash, or the receipt if `sync`. */
	async function submit(
		submitted: SubmittedTx,
		sync: boolean,
	): Promise<unknown> {
		refuseIfOverBlockGasLimit(submitted.tx);
		refuseIfBelowIntrinsicGas(submitted.tx);
		const h = txHashOf(submitted.tx);
		if (miningConfig.type === 'auto') {
			await executeAndMine([submitted]);
		} else {
			pending.push(submitted);
			if (sync) await mineBlock();
		}
		if (!sync) return h;
		const r = receipts.get(h);
		return r ? receiptToRpc(r) : null;
	}

	/**
	 * The nonce `address` sends with next: its account nonce, advanced past each
	 * CONTIGUOUS queued transaction of its own (manual/interval mining; the queue
	 * is always empty under auto mining). Contiguous, as geth counts it: a queued
	 * nonce beyond a gap does not advance it, because that transaction will not
	 * execute until the gap is filled.
	 */
	async function pendingNonce(address: Address): Promise<bigint> {
		let n = (await sm.getAccount(address))?.nonce ?? 0n;
		const queued = new Set<bigint>();
		for (const q of pending)
			if (q.sender.equals(address)) queued.add(q.tx.nonce);
		while (queued.has(n)) n++;
		return n;
	}

	// ---------- block lookup helpers ----------
	/**
	 * A block TAG or NUMBER as a block number. A string that is neither is a
	 * -32602, not a JavaScript `SyntaxError` escaping from `BigInt` (which is what
	 * `eth_getBlockByNumber('yesterday')` used to throw), and not a silent `latest`.
	 */
	function resolveBlockTag(tag: unknown): number {
		if (
			tag === 'latest' ||
			tag === 'pending' ||
			tag === 'safe' ||
			tag === 'finalized' ||
			tag == null
		)
			return latestNumber;
		if (tag === 'earliest') return 0;
		// A 32-byte hex string is a block HASH, which this parameter does not take:
		// read as a number it would be ~1e76 and look like "far above the head".
		if (typeof tag === 'string' && /^0x[0-9a-fA-F]{64}$/.test(tag))
			throw new RpcError(
				-32602,
				`invalid block parameter: ${tag} is a block hash, and this parameter takes a block number or tag.`,
			);
		if (typeof tag === 'string' && /^0x[0-9a-fA-F]+$/.test(tag))
			return Number(BigInt(tag));
		if (typeof tag === 'number' && Number.isSafeInteger(tag) && tag >= 0)
			return tag;
		throw new RpcError(
			-32602,
			`invalid block parameter: ${JSON.stringify(tag)}. Expected a block tag (latest, pending, safe, finalized, earliest) or a hex block number.`,
		);
	}

	/**
	 * THE GATE FOR EVERY STATE READ AT A BLOCK: `undefined` when the parameter
	 * names the head (read or execute live), the block number K when it names a
	 * block in the `stateHistory` window (served from the undo log), and a refusal
	 * otherwise. Every method that reads STATE at a block (`eth_call`,
	 * `eth_estimateGas`, `eth_getBalance`, `eth_getCode`, `eth_getStorageAt`,
	 * `eth_getTransactionCount`) calls this with its block parameter BEFORE
	 * touching state.
	 *
	 * ## Why this exists
	 *
	 * Those methods used to ignore the block parameter entirely and answer from the
	 * live state, while `eth_getLogs` and `eth_getBlockByNumber` honoured theirs. A
	 * client that pins a PAIR of reads to one block so they describe the same moment
	 * (logs up to block N, and a view call at block N) got logs as of N and storage
	 * as of the head: a position whose move it could not find, with no error. That is
	 * a different answer from every other node, delivered silently, which is the one
	 * outcome that is not acceptable. (This gate was `requireHeadState` while the
	 * node served the head only.)
	 *
	 * ## What the node holds: the head, plus an OPT-IN undo log
	 *
	 * This node holds ONE state: the live one. On every node the
	 * state manager's checkpoint/overlay stack is the journal of the execution in
	 * flight, not a history of blocks. Without `stateHistory` nothing of block N
	 * survives the mining of N+1, and the honest answer to "what was the state at
	 * N" is "not available here".
	 *
	 * WITH `stateHistory: {blocks: N}` the node keeps, per mined block, the value
	 * every key the block changed had BEFORE it (the sealed change sets, an undo
	 * log over the one flat state; see
	 * `docs/adr/0013-bounded-state-history-is-an-undo-log-over-the-flat-state.md`).
	 * The four POINT reads at a block K in the window are answered from it by
	 * {@link historicalValue} with no state manager involvement and no checkpoint.
	 * `eth_call` and `eth_estimateGas` at K EXECUTE: the same records, as K's
	 * state, are written into a checkpoint the request opens and reverts
	 * ({@link historicalEntries}, {@link withStateEntries}), and the engine runs
	 * with K's stored `Block`. That SUPERSEDES the reasoning this comment used to
	 * give for refusing all history (retained copies, or swapping a shared state
	 * manager's root under a read): an undo log needs neither.
	 *
	 * ## What is served, and what is refused
	 *
	 *  - SERVED: `latest`, `pending`, `safe`, `finalized`, an absent parameter, and a
	 *    number, hash or EIP-1898 `{blockNumber}` / `{blockHash}` object that names
	 *    the HEAD block. Pinning to the block you just read is the common case and it
	 *    is almost always the head, so it must keep working. (`pending` is the head
	 *    because in `manual`/`interval` mining the queued transactions have not
	 *    executed yet and this node has no speculative pending state; the one
	 *    exception is `eth_getTransactionCount`, which adds the sender's queued
	 *    transactions so that two sends before a mine get two nonces. `safe` and
	 *    `finalized` are the head because a local chain has no reorgs.) `earliest`
	 *    is served while block 0 is the head or in the window.
	 *  - SERVED FROM HISTORY: any block from {@link oldestServableBlock} up to the
	 *    head, named any of those ways, by all six methods.
	 *  - REFUSED, -32000 `historical state not available`: a block below the oldest
	 *    servable one (with no `stateHistory`, that is every block below the head),
	 *    with a message naming the oldest servable block and the `stateHistory`
	 *    option. The same code geth uses for pruned state (`missing trie node`).
	 *  - REFUSED, -32000 `header not found`: a number above the head, a hash no
	 *    block has (geth's exact wording for both), or a number between two blocks
	 *    of a chain whose numbering jumps.
	 *  - REFUSED, -32602: a parameter that is not a block at all.
	 *
	 * THE STATE AT THE HEAD INCLUDES `evm_set*` CHEATS applied since it was mined,
	 * exactly as `latest` always has: those mutate live state without a block. They
	 * are in the OPEN record, which a read below the head consults after the sealed
	 * ones, so they are visible at the head and at no older block.
	 */
	function historicalBlock(
		blockParam: unknown,
		method: string,
	): number | undefined {
		const number = pinnedBlockNumber(blockParam, method);
		if (number === latestNumber) return undefined;
		const oldest = oldestServableBlock();
		if (number < oldest) throw beyondHistory(method, number, oldest);
		// Numbering has gaps only under a `blockEnv.number` that jumps; a number
		// between two blocks names no block, and is not answered as if it did.
		if (!blockStore.has(number))
			throw new RpcError(
				-32000,
				`header not found: ${method} was pinned to block ${number}, which this node never mined.`,
			);
		return number;
	}

	/**
	 * The oldest block whose state a point read can be answered at: the head
	 * without `stateHistory`; with it, `head - N`, but never below where the undo
	 * log starts ({@link historyFloor}: genesis, or the head a state was loaded at).
	 */
	function oldestServableBlock(): number {
		if (stateHistoryBlocks === undefined) return latestNumber;
		return Math.max(historyFloor, latestNumber - stateHistoryBlocks, 0);
	}

	/** The refusal for a block older than {@link oldestServableBlock}. */
	function beyondHistory(
		method: string,
		number: number,
		oldest: number,
	): RpcError {
		const holds =
			stateHistoryBlocks === undefined
				? `but the oldest block whose state this node holds is block ${oldest}, its head, because it was created without stateHistory. ` +
					`Create the node with stateHistory: {blocks: N} to keep the last N blocks readable, or pin to the head (or 'latest') instead.`
				: `but the oldest block whose state this node holds is block ${oldest} (head ${latestNumber}, stateHistory: {blocks: ${stateHistoryBlocks}}` +
					(oldest > latestNumber - stateHistoryBlocks
						? `; history starts at block ${oldest}, where this node's state was loaded`
						: '') +
					`). Pin to a block in that window, or widen stateHistory.blocks.`;
		return new RpcError(
			-32000,
			`historical state not available: ${method} was pinned to block ${number}, ${holds} ` +
				`It REFUSES rather than answer from a later state than the one you asked for; logs and blocks remain queryable at any height.`,
		);
	}

	/**
	 * THE BLOCK NUMBER a state read's block parameter names (the head for a tag),
	 * refusing what is not a block (-32602), a hash no block has and a number above
	 * the head (-32000 `header not found`).
	 */
	function pinnedBlockNumber(blockParam: unknown, method: string): number {
		if (
			blockParam == null ||
			blockParam === 'latest' ||
			blockParam === 'pending' ||
			blockParam === 'safe' ||
			blockParam === 'finalized'
		)
			return latestNumber;
		let number: number | undefined;
		let hash: string | undefined;
		if (blockParam === 'earliest') number = 0;
		else if (typeof blockParam === 'number') number = blockParam;
		else if (typeof blockParam === 'string') {
			// A 32-byte hex string is a block HASH (geth accepts it bare, EIP-1898).
			if (/^0x[0-9a-fA-F]{64}$/.test(blockParam)) hash = blockParam;
			else if (/^0x[0-9a-fA-F]+$/.test(blockParam))
				number = Number(BigInt(blockParam));
		} else if (typeof blockParam === 'object') {
			const o = blockParam as {blockNumber?: unknown; blockHash?: unknown};
			// EIP-1898: exactly one of the two. geth refuses both at once, and so
			// does this node rather than silently preferring one.
			if (o.blockHash != null && o.blockNumber != null)
				throw new RpcError(
					-32602,
					`invalid block parameter for ${method}: pass blockHash or blockNumber, not both.`,
				);
			if (typeof o.blockHash === 'string') hash = o.blockHash;
			else if (typeof o.blockNumber === 'string') {
				if (o.blockNumber === 'earliest') number = 0;
				else if (/^0x[0-9a-fA-F]+$/.test(o.blockNumber))
					number = Number(BigInt(o.blockNumber));
				else return pinnedBlockNumber(o.blockNumber, method);
			}
		}
		if (hash !== undefined) {
			const n = blockByHash.get(hash.toLowerCase());
			if (n === undefined)
				throw new RpcError(
					-32000,
					`header not found: ${method} was pinned to block hash ${hash}, which no block on this node has.`,
				);
			number = n;
		}
		// A well-formed number too large to be a safe integer names a block far
		// above the head: that is "not found", not "not a block".
		if (number !== undefined && number > Number.MAX_SAFE_INTEGER)
			number = Number.MAX_SAFE_INTEGER;
		if (number === undefined || !Number.isSafeInteger(number) || number < 0)
			throw new RpcError(
				-32602,
				`invalid block parameter for ${method}: ${JSON.stringify(blockParam)}. ` +
					`Expected a block tag (latest, pending, safe, finalized, earliest), a hex block number, a block hash, or {blockNumber}/{blockHash}.`,
			);
		if (number > latestNumber)
			throw new RpcError(
				-32000,
				`header not found: ${method} was pinned to block ${number}, but the head of this node is block ${latestNumber}.`,
			);
		return number;
	}

	/**
	 * ONE KEY'S VALUE AT THE END OF BLOCK `k` (below the head, in the window): the
	 * FIRST record naming the key among the sealed records of blocks `k+1 .. head`
	 * (oldest first), then the OPEN record (writes since the head was mined:
	 * cheats, and a batch that threw mid-block), else the live value. Each record
	 * holds a key's value from before its block, so the first one after `k` that
	 * names the key holds its value at the end of `k`; a key no record names has
	 * not changed since `k`, so its live value is its value then.
	 *
	 * A PURE LOOKUP: no state manager write, no checkpoint, and nothing an engine
	 * sees, which is why it is safe on both engines and needs nothing from the
	 * serialisation point beyond running inside it (the dispatcher does). `pick`
	 * returns `{value}` when the record names the key, `undefined` when it does
	 * not; `live` reads the head.
	 */
	async function historicalValue<T>(
		k: number,
		pick: (changes: ChangeSet) => {value: T} | undefined,
		live: () => Promise<T>,
	): Promise<T> {
		for (const record of sealed) {
			if (record.number <= k) continue;
			const hit = pick(record.changes);
			if (hit !== undefined) return hit.value;
		}
		const open = changeSets?.peekChangeSet();
		const hit = open && pick(open);
		if (hit !== undefined) return hit.value;
		return live();
	}

	/** The account at `k`, `undefined` if absent: see {@link historicalValue}. */
	function accountAt(
		k: number,
		address: Address,
	): Promise<Account | undefined> {
		const key = address.toString();
		return historicalValue(
			k,
			(cs) =>
				cs.accounts.has(key) ? {value: cs.accounts.get(key)} : undefined,
			() => sm.getAccount(address),
		);
	}

	/** The code at `k`, empty if none: see {@link historicalValue}. */
	function codeAt(k: number, address: Address): Promise<Uint8Array> {
		const key = address.toString();
		return historicalValue(
			k,
			(cs) =>
				cs.code.has(key)
					? {value: cs.code.get(key) ?? new Uint8Array(0)}
					: undefined,
			() => sm.getCode(address),
		);
	}

	/** One storage slot at `k`, empty if unset: see {@link historicalValue}. */
	function storageAt(
		k: number,
		address: Address,
		slot: Uint8Array,
	): Promise<Uint8Array> {
		const addressKey = packAddressKey(address.bytes);
		const slotKey = packSlotKey(slot);
		return historicalValue(
			k,
			(cs) => {
				const slots = cs.storage.get(addressKey);
				return slots?.has(slotKey)
					? {value: slots.get(slotKey) ?? new Uint8Array(0)}
					: undefined;
			},
			() => sm.getStorage(address, slot),
		);
	}

	/**
	 * The stored block, as `eth_getBlockByNumber` / `eth_getBlockByHash` report it.
	 *
	 * IT READS THE SERIALISED HEADER AND NOTHING ELSE, deliberately. `sb.block` is
	 * right there and carries the same coinbase and mixHash, but it is the object
	 * `loadState` REBUILDS, so a field taken from it would be reported correctly by
	 * a live node and as zero by the same node after a reload — which is worse than
	 * a uniform zero, because nothing tells a consumer which side of the trip they
	 * are on. Every value below is therefore one a dump carries.
	 *
	 * `stateRoot` is the one REAL value among the roots (with `computeStateRoot: true`);
	 * `sha3Uncles`, `transactionsRoot` and `receiptsRoot` stay honest zero
	 * placeholders, named as such in the README, because this node builds no tries
	 * over its transactions or receipts. `logsBloom` used to be in that list and is
	 * not any more: it is the OR of the block's receipt blooms, so the standard
	 * pre-filter (test the header bloom, then call `eth_getLogs`) finds what is
	 * there instead of silently finding nothing.
	 */
	function blockToRpc(sb: StoredBlock, fullTx: boolean) {
		const h = sb.header;
		return {
			number: numHex(h.number),
			hash: h.hash,
			parentHash: h.parentHash,
			nonce: '0x0000000000000000',
			sha3Uncles: ZERO_HASH,
			logsBloom: h.logsBloom ?? EMPTY_LOGS_BLOOM,
			transactionsRoot: ZERO_HASH,
			stateRoot: h.stateRoot,
			receiptsRoot: ZERO_HASH,
			// A dump written before these fields existed carries neither, and absent
			// means ZERO rather than `undefined`: an old state loads into a block that
			// really had a zero coinbase, not into an RPC result missing a field.
			miner: h.miner ?? ZERO_ADDRESS,
			mixHash: h.mixHash ?? ZERO_HASH,
			difficulty: '0x0',
			totalDifficulty: '0x0',
			extraData: '0x',
			size: '0x0',
			gasLimit: h.gasLimit,
			gasUsed: h.gasUsed,
			timestamp: numHex(h.timestamp),
			baseFeePerGas: h.baseFeePerGas,
			uncles: [],
			transactions: fullTx
				? h.transactions.map((th) => txToRpc(transactions.get(th)!))
				: h.transactions,
		};
	}

	function txToRpc(t: SerializedTx) {
		// The 1559 fee fields are OMITTED for a legacy transaction rather than emitted as
		// `null`, which is what geth does. The difference is not cosmetic: consumers branch with
		// `'maxFeePerGas' in tx`, so a present-but-null field sends them down the 1559 path and
		// they then blow up on `BigInt(null)`. A key that exists only when it means something
		// keeps that idiom honest.
		return {
			hash: t.hash,
			nonce: numHex(t.nonce),
			blockHash: t.blockHash,
			blockNumber: numHex(t.blockNumber),
			transactionIndex: numHex(t.transactionIndex),
			from: t.from,
			to: t.to,
			value: t.value,
			gas: t.gas,
			gasPrice: t.gasPrice,
			...(t.maxFeePerGas == null ? {} : {maxFeePerGas: t.maxFeePerGas}),
			...(t.maxPriorityFeePerGas == null
				? {}
				: {maxPriorityFeePerGas: t.maxPriorityFeePerGas}),
			input: t.input,
			type: numHex(t.type),
			chainId: numHex(chainId),
		};
	}

	function receiptToRpc(r: SerializedReceipt) {
		return {
			transactionHash: r.transactionHash,
			transactionIndex: numHex(r.transactionIndex),
			blockHash: r.blockHash,
			blockNumber: numHex(r.blockNumber),
			from: r.from,
			to: r.to,
			contractAddress: r.contractAddress,
			cumulativeGasUsed: r.cumulativeGasUsed,
			gasUsed: r.gasUsed,
			effectiveGasPrice: r.effectiveGasPrice,
			status: r.status ? '0x1' : '0x0',
			type: numHex(r.type),
			logs: r.logs.map(logToRpc),
			logsBloom: r.logsBloom,
		};
	}

	/**
	 * One log as RPC serves it, from `eth_getLogs` and inside receipts alike.
	 *
	 * `blockTimestamp` (execution-apis#639, served by geth, reth, besu, erigon,
	 * anvil and Hardhat's EDR; some indexers refuse a log without it) is LOOKED UP
	 * from the log's block here rather than stored on {@link SerializedLog}. The
	 * block's header is the one source of truth for the timestamp, so a lookup
	 * cannot disagree with `eth_getBlockBy*`, and the block store is only ever
	 * cleared to be refilled by `loadState`. Storing it
	 * instead would duplicate the value on every log, change the persisted dump's
	 * shape, and leave a dump written without it needing a fallback to this very
	 * lookup anyway; as it is, every dump, old or new, answers with it.
	 */
	function logToRpc(l: SerializedLog) {
		const stored = blockStore.get(l.blockNumber);
		if (!stored) {
			// NOT unreachable today: when a manual/interval batch has a transaction
			// refused mid-batch, the receipts of the transactions before it are
			// already recorded, naming a block that is never stored (hole 2 of the
			// backlog task `two-remaining-holes-in-the-submit-and-mine-refusal-path`).
			// Such a receipt names a block that does not exist, so it is refused
			// loudly here rather than served without a timestamp, or with whatever
			// block later reuses the number. Closing that hole makes this unreachable.
			throw new Error(`log names block ${l.blockNumber}, which the node lacks`);
		}
		return {
			address: l.address,
			topics: l.topics,
			data: l.data,
			blockNumber: numHex(l.blockNumber),
			blockHash: l.blockHash,
			blockTimestamp: numHex(stored.header.timestamp),
			transactionHash: l.transactionHash,
			transactionIndex: numHex(l.transactionIndex),
			logIndex: numHex(l.logIndex),
			removed: false,
		};
	}

	/**
	 * K'S STATE, AS STATE ENTRIES: for every key the undo log names after block
	 * `k` (the sealed records of blocks `k+1 .. head`, then the OPEN record), the
	 * value it had at the end of `k`, the earliest record winning per key, exactly
	 * the lookup {@link historicalValue} makes for one key. A key no record names
	 * has not changed since `k`, so the live state already holds it and it needs
	 * no entry. O(keys changed since `k`), which is the cost of a historical
	 * `eth_call` on top of the call itself.
	 *
	 * Written into a checkpoint by {@link withStateEntries}, so the engine
	 * executes on K's state with no copy of state and no root swapped. An account
	 * absent at `k` becomes an ABSENT entry, and an account whose storage was
	 * cleared after `k` becomes a `clearStorage` entry: the clear recorded every
	 * slot the account held at that moment, so the union holds every slot it
	 * held at `k`, and clearing first also drops the slots written since.
	 *
	 * THE UNION IS BUILT FRESH. `mergeChangeSetOlderWins` is not reused here
	 * because it CONSUMES its second argument (inner storage maps are handed over
	 * whole), and these are the sealed records themselves, which a later read
	 * still needs intact.
	 */
	function historicalEntries(k: number): StateEntry[] {
		const accounts = new Map<string, Account | undefined>();
		const code = new Map<string, Uint8Array | undefined>();
		const storage = new Map<string, Map<string, Uint8Array | undefined>>();
		const cleared = new Set<string>();
		const take = (cs: ChangeSet) => {
			for (const [key, value] of cs.accounts)
				if (!accounts.has(key)) accounts.set(key, value);
			for (const [key, value] of cs.code)
				if (!code.has(key)) code.set(key, value);
			for (const [addressKey, slots] of cs.storage) {
				let target = storage.get(addressKey);
				if (target === undefined) {
					target = new Map();
					storage.set(addressKey, target);
				}
				for (const [slotKey, value] of slots)
					if (!target.has(slotKey)) target.set(slotKey, value);
			}
			for (const addressKey of cs.storageCleared) cleared.add(addressKey);
		};
		for (const record of sealed) if (record.number > k) take(record.changes);
		const open = changeSets?.peekChangeSet();
		if (open) take(open);

		// One entry per address, keyed as `address.toString()` gives it (the
		// account and code maps' key; `unpackAddressKey` yields the same form).
		const entries = new Map<string, StateEntry>();
		const entry = (key: string): StateEntry => {
			let e = entries.get(key);
			if (e === undefined) {
				e = {
					address: createAddressFromString(key),
					clearStorage: false,
					slots: [],
					absent: false,
				};
				entries.set(key, e);
			}
			return e;
		};
		for (const [key, account] of accounts) {
			const e = entry(key);
			if (account === undefined) e.absent = true;
			// A COPY: the engine is handed the object through the state manager, and
			// the sealed record must go on saying what the account was.
			else e.account = copyAccount(account);
		}
		for (const [key, value] of code)
			entry(key).code = value ?? new Uint8Array(0);
		for (const addressKey of cleared)
			entry(unpackAddressKey(addressKey)).clearStorage = true;
		for (const [addressKey, slots] of storage) {
			const e = entry(unpackAddressKey(addressKey));
			for (const [slotKey, value] of slots)
				e.slots.push({
					key: hexToBytes(unpackSlotKey(slotKey)),
					value: value ?? new Uint8Array(0),
				});
		}
		return [...entries.values()];
	}

	/**
	 * PARSE geth-STYLE STATE OVERRIDES into {@link StateEntry}s. `eth_call` and
	 * `eth_estimateGas` take them as their third parameter:
	 * `{[address]: {balance?, nonce?, code?, state?, stateDiff?}}`, where `state`
	 * REPLACES the account's whole storage and `stateDiff` patches individual
	 * slots. They used to be ignored, which answered a question the caller had not
	 * asked, with no error.
	 *
	 * PARSED BEFORE ANY LEVEL IS OPENED, into values that cannot fail to apply, so
	 * a malformed override is a -32602 naming it (never a raw `SyntaxError` from
	 * `BigInt`), and a refusal never has a half-applied override to unwind.
	 *
	 * ## What is refused
	 *
	 * `state` and `stateDiff` on the same account (geth refuses that too), and any
	 * field this node does not implement (`movePrecompileToAddress`, for one): a
	 * -32602 naming it, never a call run without it.
	 */
	function parseStateOverrides(
		overrides: unknown,
		method: string,
	): StateEntry[] {
		if (overrides == null) return [];
		if (typeof overrides !== 'object' || Array.isArray(overrides))
			throw new RpcError(
				-32602,
				`invalid state overrides for ${method}: expected an object keyed by address.`,
			);
		const supported = new Set([
			'balance',
			'nonce',
			'code',
			'state',
			'stateDiff',
		]);
		const bad = (what: string): never => {
			throw new RpcError(
				-32602,
				`invalid state override in ${method}: ${what}.`,
			);
		};
		const quantity = (v: unknown, what: string): bigint => {
			if (typeof v !== 'string' || !/^0x[0-9a-fA-F]+$/.test(v))
				return bad(`${what} must be a hex quantity, got ${JSON.stringify(v)}`);
			const n = BigInt(v);
			// A 32-byte word is the widest thing any override field names.
			if (n >= 1n << 256n) return bad(`${what} does not fit in 32 bytes`);
			return n;
		};
		const data = (v: unknown, what: string): Uint8Array => {
			if (typeof v !== 'string' || !/^0x([0-9a-fA-F]{2})*$/.test(v))
				return bad(`${what} must be even-length hex, got ${JSON.stringify(v)}`);
			return hexToBytes(v);
		};
		return Object.entries(overrides as Record<string, any>).map(
			([addr, o]): StateEntry => {
				if (o == null || typeof o !== 'object' || Array.isArray(o))
					return bad(`the override for ${addr} must be an object`);
				for (const k of Object.keys(o))
					if (!supported.has(k))
						throw new RpcError(
							-32602,
							`state override field not supported by this node: ${addr}.${k} in ${method}. ` +
								`Supported: balance, nonce, code, state, stateDiff.`,
						);
				if (o.state != null && o.stateDiff != null)
					throw new RpcError(
						-32602,
						`account ${addr} has both 'state' and 'stateDiff' in ${method}; pass one.`,
					);
				let address: Address;
				try {
					address = createAddressFromString(addr);
				} catch {
					return bad(`${JSON.stringify(addr)} is not an address`);
				}
				const slotsIn = o.state ?? o.stateDiff;
				if (
					slotsIn != null &&
					(typeof slotsIn !== 'object' || Array.isArray(slotsIn))
				)
					return bad(
						`${addr}.${o.state != null ? 'state' : 'stateDiff'} must be an object of slot -> value`,
					);
				const slots = Object.entries(slotsIn ?? {}).map(([slot, val]) => {
					const value = data(val, `${addr} slot ${slot}`);
					// A slot value is ONE word: a longer one would be silently truncated
					// to its low 32 bytes by the padding below, so it is refused.
					if (value.length > 32)
						return bad(`${addr} slot ${slot} value is longer than 32 bytes`);
					return {
						key: setLengthLeft(
							bigIntToBytes(quantity(slot, `${addr} slot key`)),
							32,
						),
						// SHORTEST FORM, as the EVM itself stores a value: a padded zero
						// and a missing slot must be the same thing to SSTORE's gas rules.
						value: unpadBytes(setLengthLeft(value, 32)),
					};
				});
				return {
					address,
					balance:
						o.balance != null
							? quantity(o.balance, `${addr}.balance`)
							: undefined,
					nonce:
						o.nonce != null ? quantity(o.nonce, `${addr}.nonce`) : undefined,
					code: o.code != null ? data(o.code, `${addr}.code`) : undefined,
					clearStorage: o.state != null,
					slots,
					absent: false,
				};
			},
		);
	}

	/**
	 * RUN A READ WITH STATE ENTRIES WRITTEN INTO A CHECKPOINT IT OPENS, and leave
	 * no trace of them. The entries are K's state for a historical call
	 * ({@link historicalEntries}) followed by the caller's state overrides
	 * ({@link parseStateOverrides}), so the overrides land ON TOP of K's state,
	 * as geth applies them on top of the block's. With no entries (a call at the
	 * head without overrides) no level is opened at all.
	 *
	 * ## Why a checkpoint here is safe, given the hazard documented at `serialise`
	 *
	 * The corruption described there needs two executions to interleave on the one
	 * checkpoint stack. This level is opened and closed by the SAME request, inside
	 * the serialisation point, with the read nested strictly inside it: the default
	 * engine's own checkpoint/revert lands on top of this one and pops before this
	 * one does, and revm reads the top of the stack on every access and never
	 * commits. So the stack is `[base, entries, (call)]` and unwinds in order,
	 * whether the read returns, reverts or throws (the `finally`). It is also the
	 * same mechanism `evmCall` already relies on for purity, one level lower. The
	 * derived trie of a `computeStateRoot` node is never involved: change-set recording is
	 * suspended for the read and the level is reverted, so nothing it wrote is
	 * ever named to the trie.
	 */
	async function withStateEntries<T>(
		entries: readonly StateEntry[],
		read: () => Promise<T>,
	): Promise<T> {
		if (entries.length === 0) return read();
		await sm.checkpoint();
		try {
			for (const e of entries) await applyStateEntry(e);
			return await read();
		} finally {
			await sm.revert();
		}
	}

	/**
	 * WRITE ONE {@link StateEntry} into the top level. The ONE apply step shared by
	 * the RPC override path and the historical path.
	 *
	 * ORDER MATTERS, and each step re-reads the account so no step writes back a
	 * stale copy over the previous one:
	 *
	 *  1. CODE FIRST. `putCode` rewrites the account's `codeHash`, and CREATES an
	 *     empty account when there is none, so it must come before
	 *     anything that states the account.
	 *  2. THE ACCOUNT: a whole account replaces what `putCode` left (its `codeHash`
	 *     is K's own), and `balance` / `nonce` are a read-modify-write on top.
	 *  3. STORAGE: a clear, then the slots.
	 *  4. ABSENT LAST: an empty code entry, then `deleteAccount`. The account must
	 *     read as ABSENT, not as a zero account, and two upstream behaviours stand
	 *     in the way: `putCode` creates an account (so the code is emptied BEFORE
	 *     the delete), and `deleteAccount` leaves the address's code in the code
	 *     map, where `eth_getCode` and the default engine's `EXTCODESIZE` would
	 *     still see it (so the code is emptied at all). `deleteAccount` also clears
	 *     the storage.
	 */
	async function applyStateEntry(e: StateEntry): Promise<void> {
		if (e.code !== undefined) await sm.putCode(e.address, e.code);
		if (e.account !== undefined) await sm.putAccount(e.address, e.account);
		if (e.balance !== undefined || e.nonce !== undefined) {
			const acc = (await sm.getAccount(e.address)) ?? new Account();
			if (e.balance !== undefined) acc.balance = e.balance;
			if (e.nonce !== undefined) acc.nonce = e.nonce;
			await sm.putAccount(e.address, acc);
		}
		if (e.clearStorage) await sm.clearStorage(e.address);
		for (const {key, value} of e.slots)
			await sm.putStorage(e.address, key, value);
		if (e.absent) {
			await sm.putCode(e.address, new Uint8Array(0));
			await sm.deleteAccount(e.address);
		}
	}

	/**
	 * geth's `eth_call` takes BLOCK overrides as a fourth parameter. This node does
	 * not implement them, so a request carrying them is refused rather than run
	 * against the real block environment.
	 */
	function refuseBlockOverrides(blockOverrides: unknown, method: string): void {
		if (blockOverrides == null) return;
		throw new RpcError(
			-32602,
			`block overrides are not supported by this node (${method}, 4th parameter). ` +
				`The call would otherwise run against the real block environment.`,
		);
	}

	// ---------- eth_call / estimateGas through the ENGINE's READ half (no signing) ----
	/**
	 * The node's single pure-read helper, and the read half of the engine seam: it
	 * normalises RPC params into a {@link ReadCallRequest} and hands them to the
	 * engine's `call`.
	 * Three dispatcher cases use it (`eth_call`, `eth_estimateGas` and
	 * `eth_fillTransaction`'s estimation).
	 *
	 * Keeping a read PURE is the engine's job, not this function's — the default
	 * `@ethereumjs/evm` engine checkpoints/reverts and resets EIP-2929 warmth
	 * because that EVM requires it; an engine that cannot commit pays for neither.
	 * See ./engine.ts.
	 *
	 * `block` is the block the call executes IN: the head's for a call at the
	 * head, block K's stored `Block` for a call pinned to K, so `NUMBER`,
	 * `TIMESTAMP`, `COINBASE`, `PREVRANDAO`, `BASEFEE` and `GASLIMIT` are K's. It
	 * also bounds `BLOCKHASH`: both engines answer zero for any number at or above
	 * the block's own, so a call at K cannot see the hash of K or of anything
	 * after it without any further mechanism (measured on both engines by
	 * `test/historical-call.spec.ts` and its revm twin).
	 */
	async function evmCall(
		params: any,
		block: Block,
		budget?: bigint,
	): Promise<ReadCallResult> {
		const from = params.from
			? createAddressFromString(params.from)
			: createAddressFromString('0x0000000000000000000000000000000000000000');
		const to = params.to ? createAddressFromString(params.to) : undefined;
		const data = params.data
			? hexToBytes(params.data)
			: params.input
				? hexToBytes(params.input)
				: new Uint8Array();
		const value = params.value ? BigInt(params.value) : 0n;
		// THE DEFAULT READ BUDGET IS A CONSTANT, DELIBERATELY NOT `blockGasLimit`.
		// They are the same number by default (30,000,000) and it would be easy to
		// read the second off the first, but they answer different questions and are
		// DECIDED APART. That is recorded here because a `blockGasLimit` a consumer
		// may now have to raise (it is what buys back the block-gas-limit relaxation
		// the engines used to disagree about; see `refuseIfOverBlockGasLimit` above)
		// makes the link actively harmful:
		//  - A BLOCK GAS LIMIT is a property of the chain a transaction is mined into,
		//    visible to a contract as `GASLIMIT`. A READ BUDGET is how long an
		//    `eth_call` with no `gas` may run before it halts. Linking them means
		//    `createNode({blockGasLimit: 10_000_000_000n})` silently buys every
		//    unbudgeted `eth_call` a 300x longer runaway, and the browser tab that
		//    locks up is nowhere near the option that caused it.
		//  - The constant is also QUOTED as a fixed number by the revm engine's
		//    hardfork refusals (`REVM_REFUSED_HARDFORKS.osaka` compares it against
		//    EIP-7825's 16,777,216 cap in src/revm.ts), which a per-node value would
		//    make wrong for some nodes and right for others.
		// A caller who wants a bigger budget passes `gas` on the call itself, which is
		// the standard `eth_call` field for exactly this and needs no configuration.
		//
		// `budget` OVERRIDES BOTH, and exactly one caller passes it: the
		// `estimateGas` search below, which is asking a different question from
		// "how long may this call run". It probes a candidate gas LIMIT, and the
		// gas that reaches the frame under that limit is the limit MINUS the
		// intrinsic cost the transaction pays first — so the search computes the
		// budget itself and this function must not re-derive one from `params.gas`,
		// which for `eth_estimateGas` is a CAP on the limit rather than a budget.
		const gasLimit =
			budget ?? (params.gas ? BigInt(params.gas) : DEFAULT_READ_BUDGET);
		return engine.call({
			from,
			to,
			data,
			value,
			gasLimit,
			block,
		});
	}

	/**
	 * THE SMALLEST GAS LIMIT AT WHICH THIS REQUEST SUCCEEDS — a SEARCH, not a
	 * measurement, and the difference is the whole point of this function.
	 *
	 * ## Why measuring is the wrong answer
	 *
	 * This method used to run the request once and report what it CONSUMED
	 * (`executionGasUsed` + intrinsic gas), which is exact and is not what the
	 * caller asked for. A client turns this number into a transaction's gas LIMIT,
	 * and under EIP-150's 63/64 rule a `CALL` or `CREATE` forwards at most 63/64 of
	 * the gas remaining at that point: a transaction whose limit equals its total
	 * consumption therefore starves its own sub-call by the 1/64 the outer frame
	 * keeps. Consumption is a LOWER BOUND on the limit, never the limit.
	 *
	 * That is not theoretical. Deploying through the standard CREATE2 factory
	 * (`0x4e59b448...`, a plain call whose body does one `CREATE2`) with a limit
	 * taken from this method returned a receipt with `status: 0x0` and no created
	 * contract, while the factory itself, the funding transfer and a proxy pointing
	 * at the address that was never deployed all mined fine — so the failure landed
	 * nowhere near its cause: a proxy delegatecalling an address with no code, which
	 * answers `0x` rather than failing. The same shape is recorded from the other
	 * side in `test/helpers/post-state.ts`, where an estimate-sized limit made an
	 * inner `SSTORE` run out of gas while the receipt still said success.
	 *
	 * So this searches for the smallest limit at which the request SUCCEEDS, which
	 * is what geth's `eth_estimateGas` has always done and for exactly this reason.
	 *
	 * ## The shape, and what each step costs
	 *
	 * 1. ONE RUN AT THE UPPER BOUND (the caller's `gas` if it named one, capped at
	 *    the block gas limit — see below). If the request fails there it fails
	 *    everywhere, and this method throws instead of returning a plausible number
	 *    that would fail on submission.
	 * 2. ONE PROBE AT THE MEASURED CONSUMPTION. A request that makes no sub-call and
	 *    no create succeeds at exactly what it consumed, so the common case (a
	 *    transfer, an `SSTORE`, a deployment) is answered EXACTLY, in one extra
	 *    execution, and the search below never runs. This is the short-circuit, and
	 *    it is a probe rather than a static "does this request call out?" test
	 *    because only the EVM knows: the answer lives in the callee's bytecode.
	 * 3. A SEARCH in `(consumption, upper bound]`, which brackets the answer from
	 *    BELOW at the scale of the 63/64 rule before bisecting, so a window that
	 *    starts 30,000,000 wide is never walked down from the top. Bounded by
	 *    {@link MAX_ESTIMATE_PROBES}; on exhaustion it returns the smallest limit it
	 *    has PROVEN to succeed, which over-estimates rather than under-estimates.
	 *
	 * ## Consumption as the lower bound, and the one case it is not one
	 *
	 * `low` starts at the measured consumption and is treated as KNOWN-FAILING
	 * (step 2 has just proven it), which is safe for every transaction whose cost
	 * does not depend on the gas it is given. A transaction that reads `GAS` and
	 * spends what it finds consumes MORE at a higher limit, so its consumption at
	 * the upper bound is not a lower bound on the minimum successful limit. geth
	 * documents the same caveat and makes the same choice: the alternative is to
	 * start the search at the intrinsic floor and pay ~11 more executions on every
	 * estimate, to serve a transaction whose "minimum" limit is meaningless anyway.
	 * The result stays a limit at which the transaction SUCCEEDS, which is the
	 * property that matters.
	 *
	 * ## The intrinsic terms are the search's floor, not an addend to its result
	 *
	 * `overhead` is what the transaction pays before its first opcode: the shared
	 * intrinsic formula (base + calldata + the EIP-3860 initcode term) PLUS the
	 * request's EIP-2930 access list, which the engine never sees (`ReadCallRequest`
	 * carries none on either engine), charged here by the one caller that has a
	 * request to read it off. Every candidate limit is probed as
	 * `budget = limit - overhead`, so the frame gets exactly the gas the mined
	 * transaction would give it, and every number this method can return is at least
	 * `overhead`. That last clause is load-bearing: `refuseIfBelowIntrinsicGas`
	 * points callers HERE for "the number a transaction needs", so the node must
	 * never refuse a limit it has just recommended.
	 */
	async function estimateGas(p: any, block: Block): Promise<bigint> {
		const dataHex: string = p.data ?? p.input ?? '0x';
		const isCreate = !p.to;
		const overhead =
			intrinsicGas(dataHex, isCreate, common) + accessListGas(p.accessList);

		// THE UPPER BOUND, and why it is capped at the block gas limit even when the
		// caller named a larger `gas`: a limit above it is REFUSED at submit by
		// `refuseIfOverBlockGasLimit`, so recommending one would be the node handing
		// back a number it will not accept. `gas` on an `eth_estimateGas` request is
		// geth's cap on the SEARCH ("do not consider limits above this"), which is a
		// different thing from `gas` on an `eth_call` ("let it run this long").
		//
		// AT A PAST BLOCK K THE CAP IS STILL THIS ONE, not K's own `gasLimit`,
		// deliberately (historical-eth-call): the number is for a transaction to be
		// SUBMITTED now, and what it meets is the limit of the blocks this node
		// mines, whatever K's was. `block` only decides what the probes execute in.
		const supplied = p.gas != null ? BigInt(p.gas) : undefined;
		const cap =
			supplied === undefined || supplied > minedBlockGasLimit
				? minedBlockGasLimit
				: supplied;

		// Nothing to search: the cap cannot pay for the transaction's own bytes, so
		// no limit within it reaches an opcode. Said in the vocabulary of the refusal
		// that would meet such a limit at submit, and NOT as `execution reverted`:
		// nothing executed, and a client reading a revert here would look for return
		// data that does not exist.
		if (cap < overhead) {
			throw new RpcError(
				-32000,
				`gas required exceeds allowance (${cap}): this transaction pays ${overhead} gas ` +
					`for its 21000 base, its calldata and its access list before its first opcode ` +
					`runs, so no gas limit within the allowance could start it. ` +
					(supplied !== undefined && supplied <= minedBlockGasLimit
						? `The allowance is the \`gas\` you passed on the request; raise it or omit it.`
						: `The allowance is this node's block gas limit; raise it with createNode({blockGasLimit: ...}).`),
			);
		}

		const probe = (limit: bigint) => evmCall(p, block, limit - overhead);

		// 1) THE UPPER BOUND, run first: a request that cannot succeed with all the
		// gas there is cannot succeed at all, and the caller learns that here rather
		// than from a receipt.
		const top = await probe(cap);
		if (top.error) {
			// TWO WAYS TO FAIL AT THE TOP, AND THEY ARE DIFFERENT PROBLEMS. A request
			// that BURNED THE WHOLE ALLOWANCE and produced no callee bytes ran out of
			// gas: nothing reverted, there is no revert data to decode, and the caller's
			// problem is the allowance rather than the contract. geth says `gas required
			// exceeds allowance` to that, at -32000, which is what the `cap < overhead`
			// refusal above already says — so this branch keeps the two consistent
			// instead of flattening one of them into a revert a client would then hunt
			// for return data on.
			//
			// THE TEST IS STRUCTURAL, not a vocabulary: "did it consume everything it
			// was given, with nothing to show for it". Both engines report the whole
			// budget as spent when a frame halts for want of gas (revm's
			// `totalGasSpent` less the intrinsic the engine added back, the default
			// engine's `executionGasUsed`), and neither's WORDS for it are the other's
			// — matching on `out of gas` would be one engine's string asserted on both,
			// the mistake `rejectionMessage` in ./revm.ts exists to avoid. A REVERT
			// keeps its bytes and its gas, and a refusal BEFORE execution (an
			// unaffordable value) spends none, so both fall through to the clause below.
			// `budget > 0` because a zero budget makes "spent everything" vacuously
			// true, and a caller who passed `gas` equal to the intrinsic floor exactly
			// is better served by the engine's own words.
			const budget = cap - overhead;
			if (
				budget > 0n &&
				top.executionGasUsed >= budget &&
				top.returnValue.length === 0
			) {
				throw new RpcError(
					-32000,
					`gas required exceeds allowance (${cap}): the transaction consumed the ENTIRE ` +
						`allowance and still did not succeed, so it needs more gas than the allowance ` +
						`permits (or it cannot succeed at all — an invalid opcode also spends everything). ` +
						`Nothing reverted, so there is no revert reason to decode. ` +
						(supplied !== undefined && supplied <= minedBlockGasLimit
							? `The allowance is the \`gas\` you passed on the request; raise it or omit it.`
							: `The allowance is this node's block gas limit, which is also the most a transaction ` +
								`it mines may ask for; raise it with createNode({blockGasLimit: ...}). `) +
						`The engine reported: ${String(top.error)}.`,
				);
			}
			const reason = revertReason(top.returnValue);
			// The LEADING CLAUSE stays `execution reverted` and the return data stays
			// on `data`, because that pair is what a client decodes (viem turns it into
			// a typed revert error and reads the reason out of the bytes) and because
			// the node flattens every engine failure into it on the read path. What is
			// added is the part only this method knows: that the failure is not a
			// shortage of gas (the branch above owns that case), so there is no number
			// to report.
			throw new RpcError(
				3,
				`execution reverted: the transaction fails at EVERY gas limit up to ${cap}, ` +
					`so there is no limit that would make it succeed and no estimate to report. ` +
					(reason !== undefined
						? `Revert reason: ${reason}. `
						: top.returnValue.length > 0
							? `It reverted with data (see \`data\`), which is not a standard Error(string). `
							: `It returned no revert data. `) +
					`The engine reported: ${String(top.error)}.`,
				hex(top.returnValue),
			);
		}

		// 2) WHAT IT CONSUMED, and the probe that tests whether consumption is also a
		// workable limit. `consumed >= cap` means the request needs everything the
		// cap allows, and the cap has just been proven to work, so it IS the answer.
		const consumed = top.executionGasUsed + overhead;
		if (consumed >= cap) return cap;
		if (!(await probe(consumed)).error) return consumed;

		// 3) THE SEARCH, in two phases. `low` FAILS and `high` SUCCEEDS at every
		// point, so `high` is at all times a limit this transaction has been PROVEN
		// to succeed at — including when the probe budget runs out mid-search.
		let low = consumed;
		let high = cap;
		let probes = 0n;

		// PHASE 1 — BRACKET THE ANSWER FROM BELOW, at the scale of the rule that
		// causes the gap. A frame that hands 63/64 of its gas to a sub-call is short
		// by about 1/64 of what it held, and by about another 1/64 per nesting level
		// below that, so the first candidate above the measured consumption is
		// `low + low/64` and the step DOUBLES until it brackets the answer. Starting
		// at the top of the window instead (a plain bisection of `consumption`..`the
		// block gas limit`) means executing the request at 15,000,000 gas to learn
		// what a probe 3,000 gas above consumption would have said.
		let step = low / 64n;
		if (step < 1n) step = 1n;
		while (probes < MAX_ESTIMATE_PROBES && low + step < high) {
			const candidate = low + step;
			probes++;
			if ((await probe(candidate)).error) {
				low = candidate;
				step *= 2n;
			} else {
				high = candidate;
				break;
			}
		}

		// PHASE 2 — BISECT WHAT PHASE 1 BRACKETED, which is the ordinary binary
		// search and the only part that can make the answer EXACT.
		while (probes < MAX_ESTIMATE_PROBES && low + 1n < high) {
			const mid = low + (high - low) / 2n;
			probes++;
			if ((await probe(mid)).error) low = mid;
			else high = mid;
		}
		return high;
	}

	// ---------- the EIP-1193 dispatcher ----------
	async function request(args: RequestArguments): Promise<unknown> {
		const params = (args.params ?? []) as any[];
		switch (args.method) {
			case 'eth_chainId':
				return numHex(chainId);
			case 'net_version':
				return String(chainId);
			case 'eth_blockNumber':
				return numHex(latestNumber);

			case 'eth_getBlockByNumber': {
				const sb = blockStore.get(resolveBlockTag(params[0]));
				return sb ? blockToRpc(sb, Boolean(params[1])) : null;
			}
			case 'eth_getBlockByHash': {
				const num = blockByHash.get(String(params[0]).toLowerCase());
				const sb = num != null ? blockStore.get(num) : undefined;
				return sb ? blockToRpc(sb, Boolean(params[1])) : null;
			}

			// AT THE HEAD OR AT A BLOCK K IN THE `stateHistory` WINDOW, through the one
			// gate every state read uses (`historicalBlock`). At K the engine runs with
			// K's stored `Block` on K's state, written into a checkpoint the request
			// opens and reverts (`historicalEntries`, `withStateEntries`), with the
			// caller's state overrides applied ON TOP of it.
			case 'eth_call': {
				const k = historicalBlock(params[1], 'eth_call');
				refuseBlockOverrides(params[3], 'eth_call');
				const entries = [
					...(k === undefined ? [] : historicalEntries(k)),
					...parseStateOverrides(params[2], 'eth_call'),
				];
				const block = blockStore.get(k ?? latestNumber)!.block;
				const r = await pureRead(() =>
					withStateEntries(entries, () => evmCall(params[0] ?? {}, block)),
				);
				if (r.error)
					throw new RpcError(3, 'execution reverted', hex(r.returnValue));
				return hex(r.returnValue);
			}
			case 'eth_estimateGas': {
				// THE SMALLEST GAS LIMIT AT WHICH THIS REQUEST SUCCEEDS, found by
				// re-executing it. The whole method is {@link estimateGas} above,
				// including why it is a search rather than the run-and-measure it used to
				// be, and where the request's EIP-2930 access list is charged. The whole
				// search runs inside ONE checkpoint holding K's state (and the overrides).
				const k = historicalBlock(params[1], 'eth_estimateGas');
				refuseBlockOverrides(params[3], 'eth_estimateGas');
				const entries = [
					...(k === undefined ? [] : historicalEntries(k)),
					...parseStateOverrides(params[2], 'eth_estimateGas'),
				];
				const block = blockStore.get(k ?? latestNumber)!.block;
				return numHex(
					await pureRead(() =>
						withStateEntries(entries, () =>
							estimateGas(params[0] ?? {}, block),
						),
					),
				);
			}

			case 'eth_fillTransaction': {
				// Fill the missing fields of a tx request and return {tx, raw} like geth
				// does (the `raw` is the UNSIGNED serialization — the node has no keys; a
				// client signs client-side). viem's prepareTransactionRequest probes this
				// to fill nonce/gas/fees in one round-trip; it reads the filled fields off
				// `tx` and re-signs itself, so an unsigned `raw` is correct here.
				const p = params[0] ?? {};
				const from = p.from
					? createAddressFromString(p.from)
					: createAddressFromString(
							'0x0000000000000000000000000000000000000000',
						);
				// The PENDING nonce, as geth fills it: the account's nonce advanced past
				// the transactions it already has queued.
				const nonce =
					p.nonce != null ? BigInt(p.nonce) : await pendingNonce(from);
				const value = p.value != null ? BigInt(p.value) : 0n;
				const dataHex: string = p.data ?? p.input ?? '0x';
				const isCreate = !p.to;
				// Gas: the SAME search `eth_estimateGas` runs, unless the caller fixed it.
				// It has to be the same one: what this method fills is a gas LIMIT, and a
				// limit equal to measured consumption starves a sub-call under EIP-150's
				// 63/64 rule exactly as it does there (see {@link estimateGas}).
				//
				// WITH THE ACCESS LIST DELIBERATELY DROPPED, which is this method's one
				// documented difference and is unchanged: the transaction it FILLS AND
				// RETURNS carries no access list (it builds a type-0 or type-2 envelope
				// and drops the field), so charging for a list its own answer does not
				// contain would hand back a gas limit for a different transaction. See
				// `accessListGas` in ./intrinsic-gas.ts.
				const gas: bigint =
					p.gas != null
						? BigInt(p.gas)
						: await pureRead(() =>
								estimateGas(
									{...p, gas: undefined, accessList: undefined},
									blockStore.get(latestNumber)!.block,
								),
							);
				// Fee fields: legacy iff caller passed gasPrice (and no 1559 fields),
				// otherwise EIP-1559 with the node's constant fee market.
				const isLegacy =
					p.gasPrice != null &&
					p.maxFeePerGas == null &&
					p.maxPriorityFeePerGas == null;
				const type = isLegacy ? 0 : 2;
				const txData: any = {
					nonce,
					gasLimit: gas,
					value,
					data: hexToBytes(dataHex.startsWith('0x') ? dataHex : '0x' + dataHex),
					to: p.to ?? undefined,
					type,
				};
				if (isLegacy) {
					txData.gasPrice = p.gasPrice != null ? BigInt(p.gasPrice) : gasPrice;
				} else {
					txData.maxFeePerGas =
						p.maxFeePerGas != null
							? BigInt(p.maxFeePerGas)
							: baseFeePerGas + maxPriorityFeePerGas;
					txData.maxPriorityFeePerGas =
						p.maxPriorityFeePerGas != null
							? BigInt(p.maxPriorityFeePerGas)
							: maxPriorityFeePerGas;
					txData.chainId = chainId;
				}
				const unsigned = createTx(txData, {common});
				// Build the RPC transaction object viem reads its filled fields off of.
				const tx = {
					from: from.toString(),
					to: p.to ?? null,
					nonce: numHex(nonce),
					gas: numHex(gas),
					value: numHex(value),
					input: hex(txData.data),
					type: numHex(type),
					chainId: numHex(chainId),
					gasPrice: isLegacy ? numHex(txData.gasPrice) : null,
					maxFeePerGas: isLegacy ? null : numHex(txData.maxFeePerGas),
					maxPriorityFeePerGas: isLegacy
						? null
						: numHex(txData.maxPriorityFeePerGas),
					// placeholders viem deletes from the formatted tx (blockHash etc.)
					hash: ZERO_HASH,
					blockHash: null,
					blockNumber: null,
					transactionIndex: null,
					v: '0x0',
					r: ZERO_HASH,
					s: ZERO_HASH,
				};
				return {raw: hex(unsigned.serialize()), tx};
			}

			// EVERY state read at a block is gated first: served at the head, served
			// from the undo log inside the `stateHistory` window (these four only,
			// through `historicalBlock`), and REFUSED below it, never answered from the
			// head for a block that is not the head.
			case 'eth_getBalance': {
				const k = historicalBlock(params[1], 'eth_getBalance');
				const address = createAddressFromString(params[0]);
				const acc =
					k === undefined
						? await sm.getAccount(address)
						: await accountAt(k, address);
				return numHex(acc?.balance ?? 0n);
			}
			case 'eth_getTransactionCount': {
				const k = historicalBlock(params[1], 'eth_getTransactionCount');
				const address = createAddressFromString(params[0]);
				if (k !== undefined)
					return numHex((await accountAt(k, address))?.nonce ?? 0n);
				// `pending` COUNTS THE QUEUED TRANSACTIONS, the one state read where it
				// differs from the head: a client picking a nonce asks for `pending`
				// (viem does by default), and in manual/interval mining two sends
				// before a mine would otherwise get the SAME nonce, the second then
				// refused at mine time as a replay.
				return numHex(
					params[1] === 'pending'
						? await pendingNonce(address)
						: ((await sm.getAccount(address))?.nonce ?? 0n),
				);
			}
			case 'eth_getCode': {
				const k = historicalBlock(params[1], 'eth_getCode');
				const address = createAddressFromString(params[0]);
				return hex(
					k === undefined
						? await sm.getCode(address)
						: await codeAt(k, address),
				);
			}
			case 'eth_getStorageAt': {
				const k = historicalBlock(params[2], 'eth_getStorageAt');
				const addr = createAddressFromString(params[0]);
				const slot = setLengthLeft(bigIntToBytes(BigInt(params[1])), 32);
				const val =
					k === undefined
						? await sm.getStorage(addr, slot)
						: await storageAt(k, addr, slot);
				return hex(setLengthLeft(val, 32));
			}

			// ---- Runtime state cheats (anvil/hardhat-style; for tests/local tooling) ----
			// These MUTATE state directly (no tx). Honest about being non-standard: they
			// are `evm_*`-namespaced. They write the flat state only; on a `computeStateRoot` node the
			// open record names what they wrote, so the next getStateRoot() (or mined
			// block) rehashes it into the derived trie.
			case 'evm_setBalance': {
				// params: [address, valueHex]
				const addr = createAddressFromString(params[0]);
				await mutateAccount(addr, (acc) => {
					acc.balance = BigInt(params[1]);
				});
				return true;
			}
			case 'evm_setNonce': {
				// params: [address, nonceHex]
				const addr = createAddressFromString(params[0]);
				await mutateAccount(addr, (acc) => {
					acc.nonce = BigInt(params[1]);
				});
				return true;
			}
			case 'evm_setCode': {
				// params: [address, codeHex]
				const addr = createAddressFromString(params[0]);
				await sm.putCode(addr, hexToBytes(params[1]));
				return true;
			}
			case 'evm_setStorageAt': {
				// params: [address, slotHex, valueHex(32-byte)]
				const addr = createAddressFromString(params[0]);
				const slot = setLengthLeft(bigIntToBytes(BigInt(params[1])), 32);
				await sm.putStorage(
					addr,
					slot,
					setLengthLeft(hexToBytes(params[2]), 32),
				);
				return true;
			}
			case 'evm_setAccount': {
				// params: [address, {balance?, nonce?, code?, storage?}] — set all at once.
				const addr = createAddressFromString(params[0]);
				const a = params[1] ?? {};
				await mutateAccount(addr, (acc) => {
					if (a.balance != null) acc.balance = BigInt(a.balance);
					if (a.nonce != null) acc.nonce = BigInt(a.nonce);
				});
				if (a.code != null && a.code !== '0x')
					await sm.putCode(addr, hexToBytes(a.code));
				for (const [slot, val] of Object.entries(a.storage ?? {})) {
					await sm.putStorage(
						addr,
						setLengthLeft(bigIntToBytes(BigInt(slot)), 32),
						setLengthLeft(hexToBytes(val as string), 32),
					);
				}
				return true;
			}

			// ---- Time cheats (anvil/hardhat-style): move THE NODE'S CLOCK ----
			// They change what the NEXT mined block is stamped with and nothing
			// already mined; see the clock's own comment for the order a block reads
			// them in. Like the state cheats they are `evm_*`-namespaced.
			case 'evm_setNextBlockTimestamp': {
				// params: [timestamp] — the next block's, once; later than the head's.
				nextTimestamp = laterThanHead(params[0], 'evm_setNextBlockTimestamp');
				return true;
			}
			case 'evm_increaseTime': {
				// params: [seconds] — added to the offset; returns the total offset.
				timeOffset += seconds(params[0], 'evm_increaseTime');
				return numHex(timeOffset);
			}
			case 'evm_setBlockTimestampInterval': {
				// params: [seconds] — each block is its parent's plus this; > 0.
				const s = seconds(params[0], 'evm_setBlockTimestampInterval');
				if (s === 0n)
					throw new RpcError(
						-32602,
						'evm_setBlockTimestampInterval: the interval must be at least one second',
					);
				timestampInterval = s;
				return true;
			}
			case 'evm_removeBlockTimestampInterval': {
				// returns whether an interval was set.
				const was = timestampInterval !== undefined;
				timestampInterval = undefined;
				return was;
			}
			case 'evm_mine': {
				// params: [] or [timestamp] — mine one block NOW, with whatever is
				// pending (nothing under auto mining, so an empty block): the RPC form
				// of `node.mine()`, already inside the serialisation point. A timestamp
				// is `evm_setNextBlockTimestamp` for this block. Anvil's object form
				// (`{timestamp, blocks}`) is refused rather than half-honoured.
				if (params.length > 0 && params[0] != null) {
					if (typeof params[0] === 'object')
						throw new RpcError(
							-32602,
							'evm_mine: takes no parameter or a timestamp; the {timestamp, blocks} form is not supported',
						);
					nextTimestamp = laterThanHead(params[0], 'evm_mine');
				}
				await mineBlock();
				return '0x0';
			}

			case 'eth_gasPrice':
				return numHex(gasPrice);
			case 'eth_maxPriorityFeePerGas':
				return numHex(maxPriorityFeePerGas);
			case 'eth_feeHistory': {
				// params: [blockCount, newestBlock, rewardPercentiles]. `newestBlock` is
				// HONOURED (it used to be ignored, and the window always ended at the head),
				// and the per-block base fee and gas-used ratio are the stored blocks' own.
				// Only `reward` stays synthetic: this node's priority fee is a constant.
				const rawCount = params[0] ?? '0x1';
				const requested =
					typeof rawCount === 'number' && Number.isSafeInteger(rawCount)
						? rawCount
						: typeof rawCount === 'string' && /^0x[0-9a-fA-F]+$/.test(rawCount)
							? Number(BigInt(rawCount))
							: NaN;
				if (!(requested >= 0))
					throw new RpcError(
						-32602,
						`invalid eth_feeHistory blockCount: ${JSON.stringify(rawCount)}. Expected a hex quantity.`,
					);
				const newest = resolveBlockTag(params[1] ?? 'latest');
				if (newest > latestNumber)
					throw new RpcError(
						-32000,
						`request beyond head block: eth_feeHistory newestBlock is ${newest}, but the head of this node is block ${latestNumber}.`,
					);
				// geth caps a request at 1024 blocks, and nothing precedes block 0.
				const count = Math.max(0, Math.min(requested, 1024, newest + 1));
				const oldest = newest - count + 1;
				const nextBaseFee = (n: number): string => {
					const sb = blockStore.get(n);
					return sb
						? sb.header.baseFeePerGas
						: numHex(blockEnv?.baseFeePerGas ?? baseFeePerGas);
				};
				const ratio = (n: number): number => {
					// The header's own `gasUsed` is a documented 0x0 placeholder, so the
					// block's usage is summed from its receipts, which are real.
					const sb = blockStore.get(n);
					if (!sb) return 0;
					let used = 0n;
					for (const th of sb.header.transactions) {
						const r = receipts.get(th);
						if (r) used += BigInt(r.gasUsed);
					}
					const limit = BigInt(sb.header.gasLimit);
					return limit === 0n ? 0 : Number(used) / Number(limit);
				};
				// `reward` must carry ONE entry per requested percentile, per block. Returning a
				// single entry regardless of `rewardPercentiles` breaks any caller that asks for
				// several and indexes them: rocketh requests [10, 50, 80] and reads index 1 and 2,
				// which came back `undefined` and blew up as "Cannot mix BigInt and other types"
				// far from here. This node has a flat fee model, so every percentile is the same
				// value - but the SHAPE has to match the request.
				const percentiles = Array.isArray(params[2]) ? params[2] : [];
				const rewardPerBlock = (
					percentiles.length > 0 ? percentiles : [50]
				).map(() => numHex(maxPriorityFeePerGas));
				return {
					// An empty window is geth's empty answer, oldestBlock included.
					oldestBlock: numHex(count === 0 ? 0 : oldest),
					// One per block in the window PLUS the block after it, which is the
					// stored block when there is one and the next block this node will mine
					// when the window ends at the head.
					baseFeePerGas:
						count === 0
							? []
							: Array.from({length: count + 1}, (_, i) =>
									nextBaseFee(oldest + i),
								),
					gasUsedRatio: Array.from({length: count}, (_, i) =>
						ratio(oldest + i),
					),
					reward: Array.from({length: count}, () => rewardPerBlock),
				};
			}

			case 'eth_sendRawTransaction': {
				return submit(parseTx(params[0]), false);
			}
			case 'eth_sendRawTransactionSync': {
				// The fast path: send + mine + return receipt in ONE call. Default
				// behaviour pairs with auto mining (no receipt polling = the latency win).
				return submit(parseTx(params[0]), true);
			}

			// ---- Trusted-sender variants (senderMode:'trusted' ONLY) ----
			// Same as the eth_* pair above but take an explicit `from` and SKIP
			// ecrecover. `evm_`-namespaced because they are a cheat, not a standard
			// method: the signature on the wire is never verified.
			case 'evm_sendRawTransactionAs': {
				return submit(parseTx(params[0], params[1]), false);
			}
			case 'evm_sendRawTransactionSyncAs': {
				return submit(parseTx(params[0], params[1]), true);
			}

			case 'eth_getTransactionReceipt': {
				const r = receipts.get(String(params[0]).toLowerCase());
				return r ? receiptToRpc(r) : null;
			}
			case 'eth_getTransactionByHash': {
				const t = transactions.get(String(params[0]).toLowerCase());
				return t ? txToRpc(t) : null;
			}

			case 'eth_getLogs': {
				// PERF NOTE: this does a full linear scan + filter over `allLogs` (every
				// log ever emitted) on EVERY call — O(total_logs) per query, recomputed
				// each time, no index/cache. `allLogs` is appended in block order. For a
				// local chain this is fine (in-memory, sub-ms for thousands of logs); it
				// only matters for a long-lived session with huge log counts + frequent
				// polling. An optional index (block-range pre-slice / address / topic0)
				// is deferred — see tasks/slim-node-eth-getlogs-index.md. Keep this scan as
				// the authoritative semantics if/when an index is added.
				const f = params[0] ?? {};
				// `blockHash` (EIP-234) pins the query to ONE block. It used to be ignored,
				// which returned the logs of EVERY block. It excludes a range, as in geth,
				// and a hash no block has is an error rather than an empty result, so a
				// typo cannot read as "that block emitted nothing".
				let from: number;
				let to: number;
				if (f.blockHash != null) {
					if (f.fromBlock != null || f.toBlock != null)
						throw new RpcError(
							-32602,
							'invalid eth_getLogs filter: cannot specify both blockHash and fromBlock/toBlock.',
						);
					const n = blockByHash.get(String(f.blockHash).toLowerCase());
					if (n === undefined)
						throw new RpcError(
							-32000,
							`unknown block: eth_getLogs blockHash ${f.blockHash} is not a block on this node.`,
						);
					from = n;
					to = n;
				} else {
					// geth's default for an omitted `fromBlock` is `latest`, not 0; this
					// node has always defaulted to 0 and that is kept (changing it would
					// silently shrink every existing consumer's results).
					from = f.fromBlock != null ? resolveBlockTag(f.fromBlock) : 0;
					to = f.toBlock != null ? resolveBlockTag(f.toBlock) : latestNumber;
				}
				const addrFilter = f.address
					? (Array.isArray(f.address) ? f.address : [f.address]).map(
							(a: string) => a.toLowerCase(),
						)
					: null;
				const topics: (string | string[] | null)[] = f.topics ?? [];
				const out = allLogs.filter((l) => {
					if (l.blockNumber < from || l.blockNumber > to) return false;
					if (addrFilter && !addrFilter.includes(l.address.toLowerCase()))
						return false;
					for (let i = 0; i < topics.length; i++) {
						const want = topics[i];
						if (want == null) continue;
						const have = l.topics[i];
						if (have == null) return false;
						if (Array.isArray(want)) {
							if (
								!want.map((w) => w.toLowerCase()).includes(have.toLowerCase())
							)
								return false;
						} else if (want.toLowerCase() !== have.toLowerCase()) return false;
					}
					return true;
				});
				return out.map(logToRpc);
			}

			case 'eth_subscribe': {
				if (params[0] !== 'newHeads')
					throw new RpcError(
						-32601,
						`subscription type not supported: ${params[0]}`,
					);
				// Return an id; consumers using comlink should prefer onNewHead callback.
				const id = '0x' + Math.floor(Math.random() * 2 ** 48).toString(16);
				return id;
			}
			case 'eth_unsubscribe':
				return true;

			// ---- account/signing methods are intentionally NOT here ----
			case 'eth_sendTransaction':
			case 'eth_accounts':
			case 'eth_sign':
			case 'eth_signTransaction':
			case 'personal_sign':
			case 'personal_unlockAccount':
			case 'wallet_addEthereumChain':
			case 'wallet_switchEthereumChain':
				throw new RpcError(
					-32601,
					`method not supported (execution-only node — sign client-side and use eth_sendRawTransaction): ${args.method}`,
				);

			default:
				throw new RpcError(-32601, `method not found: ${args.method}`);
		}
	}

	// ---------- dump / load ----------
	async function dumpState(): Promise<SerializedState> {
		const accounts: Record<string, string> = {};
		const code: Record<string, string> = {};
		const storage: Record<string, Record<string, string>> = {};

		// EVERY NODE DUMPS THE SAME WAY, storage included: the account and code
		// stacks are plain Maps whose TOP frame is the live set, and storage is
		// per-account with per-checkpoint OVERLAYS, flattened by liveStorage(). A
		// `computeStateRoot` node runs on this same flat state, and its derived trie is NOT
		// serialised: `loadState` rebuilds it from the loaded flat state.
		//
		// THE SERIALISED FORMAT IS NOT THE INTERNAL LAYOUT and must not follow it:
		// this output is persisted data (IndexedDB, loadState fixtures) with existing
		// state behind it. It stays `{address: {slot: value}}` in 0x-hex, and
		// `test/storage-overlay.spec.ts` asserts it byte-identical to a dump taken
		// from the pre-overlay flat layout.
		const accMap = sm.accountStack[sm.accountStack.length - 1];
		const codeMap = sm.codeStack[sm.codeStack.length - 1];
		for (const [addr, acc] of accMap) {
			if (acc !== undefined) accounts[addr] = hex(acc.serialize());
		}
		for (const [addr, c] of codeMap) code[addr] = hex(c);
		for (const [addr, slots] of sm.liveStorage()) {
			for (const [slot, val] of slots) (storage[addr] ??= {})[slot] = hex(val);
		}

		const blocks: SerializedBlock[] = [];
		for (let i = 0; i <= latestNumber; i++) {
			const sb = blockStore.get(i);
			if (sb) blocks.push(sb.header);
		}

		return {
			version: 1,
			chainId,
			accounts,
			code,
			storage,
			blocks,
			receipts: Object.fromEntries(receipts),
			transactions: Object.fromEntries(transactions),
			// ADDITIVE: a node without `stateHistory` writes no field at all, so its
			// dump is exactly what it was before history existed.
			...(stateHistoryBlocks === undefined ? {} : {history: dumpHistory()}),
		};
	}

	/**
	 * THE UNDO LOG AS THE DUMP CARRIES IT: one serialized record per sealed block,
	 * oldest first, with the OPEN record FOLDED INTO THE HEAD'S RECORD (older
	 * entry winning).
	 *
	 * WHY FOLD rather than dump the open record as a field of its own: `loadState`
	 * treats the loaded state as a baseline and CLEARS the open record, so the
	 * writes since the head was mined (`evm_set*` cheats, a batch that threw
	 * mid-block) become part of the loaded head, which reads them live exactly as
	 * it did before the dump. What must not be lost is their prior values, which
	 * every read BELOW the head consults after the sealed records. Folding keeps
	 * the per-key earliest-wins union over `undo[K+1] .. undo[head]` + open
	 * identical for every K below the head: a key the head's record already names
	 * keeps that (older) value; a key it does not name did not change in the head
	 * block, so its value at the end of the block before equals its value at the
	 * end of the head, which is what the open record holds. The alternative, a
	 * separate `open` field restored as the open record, would make the next mined
	 * block after a reload own writes made before it, and would have been a second
	 * new field for the same answers.
	 *
	 * With NO record for the head (the head is where history starts: genesis, or a
	 * loaded head nothing was mined on), no block below the head is servable, and
	 * the open record is dropped with nothing lost.
	 *
	 * Decisions around the format (this fold, the contiguous restore, `[]` vs no
	 * key) are recorded in
	 * `work/notes/observations/state-history-persistence-decisions.md`.
	 */
	function dumpHistory(): SerializedHistoryBlock[] {
		const out = sealed.map((r) => serializeChangeSet(r.number, r.changes));
		const open = changeSets?.peekChangeSet();
		const head = out[out.length - 1];
		if (
			open !== undefined &&
			head !== undefined &&
			head.number === latestNumber
		)
			mergeSerializedOlderWins(head, serializeChangeSet(latestNumber, open));
		return out;
	}

	/**
	 * RESTORE the undo log from a dump's `history` (see {@link dumpHistory}), after
	 * the rest of the state is loaded and {@link latestNumber} is the dump's head.
	 * Only the CONTIGUOUS run of records ending at the head block is kept, newest
	 * first, stopping at the first gap and at this node's window (a record at or
	 * below `head - N` serves no block in it, so a dump with more history than N
	 * is truncated to N, and one with less serves what it has). A dump the writer
	 * produced has no gap; a hand-edited or foreign one might, and a read below a
	 * gap would silently be answered from a later state, which is the one thing
	 * the history exists not to do. {@link historyFloor} becomes the block before
	 * the oldest record kept, or the head when none is.
	 */
	function loadHistory(history: SerializedHistoryBlock[], window: number) {
		const kept: {number: number; changes: ChangeSet}[] = [];
		let expected = latestNumber;
		for (let i = history.length - 1; i >= 0; i--) {
			const record = history[i];
			if (record.number !== expected || record.number <= latestNumber - window)
				break;
			kept.push({number: record.number, changes: deserializeChangeSet(record)});
			expected--;
		}
		kept.reverse();
		sealed.push(...kept);
		historyFloor = kept.length > 0 ? kept[0].number - 1 : latestNumber;
	}

	async function loadState(state: SerializedState): Promise<void> {
		// A pending next timestamp was set against the OLD head; the loaded one may
		// already be past it (the clock's offset and interval are node settings and
		// stay).
		nextTimestamp = undefined;
		// Rehydrate accounts/code/storage directly into SimpleStateManager.
		for (const [addr, accHex] of Object.entries(state.accounts)) {
			const acc = createAccountFromRLP(hexToBytes(accHex));
			await sm.putAccount(createAddressFromString(addr), acc);
		}
		for (const [addr, c] of Object.entries(state.code)) {
			await sm.putCode(createAddressFromString(addr), hexToBytes(c));
		}
		for (const [addr, slots] of Object.entries(state.storage)) {
			for (const [slot, val] of Object.entries(slots)) {
				await sm.putStorage(
					createAddressFromString(addr),
					hexToBytes(slot),
					hexToBytes(val),
				);
			}
		}

		// Rebuild block list / receipts / tx / logs index.
		receipts.clear();
		transactions.clear();
		blockStore.clear();
		blockByHash.clear();
		allLogs = [];
		for (const [h, r] of Object.entries(state.receipts)) receipts.set(h, r);
		for (const [h, t] of Object.entries(state.transactions))
			transactions.set(h, t);

		for (const sh of state.blocks) {
			// THE REBUILT BLOCK CARRIES THE COINBASE AND THE MIXHASH, because it is not
			// only the RPC that reads it: `eth_call` executes against the STORED `Block`
			// object of the latest block, so a reconstruction that dropped them would
			// hand a contract a zero COINBASE / PREVRANDAO after a reload while the same
			// node's mined blocks used the configured ones. `difficulty` is pinned to 0
			// here for the same reason it is pinned when mining: post-Merge, PREVRANDAO
			// lives in `mixHash` and the difficulty must be zero beside it.
			//
			// AND ITS OWN HASH HAS TO COME OUT RIGHT, which is the second thing this
			// list is load-bearing for and the easier one to break. `parentHash` for the
			// next mined block is taken from THIS object's `hash()` (below), and the
			// default engine answers BLOCKHASH from it through `mockBlockchain`, so the
			// header built here must be field-for-field the one `storeBlock` recorded or
			// a reloaded chain names a parent no lookup resolves. That is an INVARIANT
			// between three places, not a local property: a header field added to the
			// mined block in `executeAndMine` has to be recorded in `SerializedBlock` and
			// restored here, or the hash silently diverges on the far side of a reload.
			// `test/rpc-block.spec.ts` mines a block after a reload and checks its parent
			// resolves, which is that invariant stated where a consumer would meet it.
			const block = createBlock(
				{
					header: {
						number: BigInt(sh.number),
						gasLimit: BigInt(sh.gasLimit),
						gasUsed: BigInt(sh.gasUsed),
						baseFeePerGas: BigInt(sh.baseFeePerGas),
						parentHash: hexToBytes(sh.parentHash),
						timestamp: BigInt(sh.timestamp),
						...(sh.miner ? {coinbase: createAddressFromString(sh.miner)} : {}),
						difficulty: 0n,
						...(sh.mixHash ? {mixHash: hexToBytes(sh.mixHash)} : {}),
					},
				},
				{common},
			);
			// Collect this block's logs from receipts (preserves order).
			const logs: SerializedLog[] = [];
			for (const th of sh.transactions) {
				const r = receipts.get(th);
				if (r) logs.push(...r.logs);
			}
			// A dump from before `SerializedBlock` had a bloom gets one REBUILT rather
			// than defaulted to zero: its receipts carry their own blooms, so the block
			// bloom is derivable, and an old state that pre-filtered to nothing would be
			// the very defect this field was added to close.
			const header: SerializedBlock =
				sh.logsBloom === undefined
					? {...sh, logsBloom: bloomOfReceipts(sh.transactions)}
					: sh;
			blockStore.set(sh.number, {block, header, logs});
			blockByHash.set(sh.hash, sh.number);
			allLogs.push(...logs);
			latestNumber = sh.number;
			parentHash = block.hash();
		}

		// A LOADED STATE IS A BASELINE, NOT HISTORY: the record is cleared, like the
		// construction baselines at genesis. The dump carries no change set for its
		// head, so there is none to report for it either.
		changeSets?.takeChangeSet();
		headBlockChangeSet = undefined;
		// ...and the history the node held described the state this load just
		// replaced, so it goes. What replaces it is the dump's own history, when the
		// dump carries one and this node keeps any: otherwise history starts again at
		// the loaded head (an older dump, or a node without `stateHistory`, which
		// ignores the field).
		sealed.length = 0;
		historyFloor = latestNumber;
		if (stateHistoryBlocks !== undefined && state.history !== undefined)
			loadHistory(state.history, stateHistoryBlocks);
		// ...and the derived trie described that replaced state too. It is REBUILT
		// from the loaded flat state, once, exactly as at construction: the dump
		// carries no trie (it never has to: the flat state determines it), and a
		// load is a baseline in no change set, so nothing else would put it there.
		if (computeStateRoot)
			derivedTrie = await DerivedStateTrie.build(sm, common);
	}

	// ---------- persistence auto-load on creation ----------
	if (options.persistence) {
		const saved = await options.persistence.load();
		if (saved && saved.chainId === chainId) await loadState(saved);
	}

	// The dump is taken inside the chain, so it is a snapshot of a settled state,
	// and the hook is AWAITED inside it too, so a request does not resolve before
	// its state is durable (`test/persistence-reload.spec.ts` reloads the page on
	// the strength of that). A request arriving while the hook runs simply queues.
	async function persistIfNeeded() {
		if (!options.persistence) return;
		await options.persistence.save(await dumpState());
	}

	/**
	 * ARM INTERVAL MINING, once the node is otherwise built.
	 *
	 * COALESCED, which a plain `setInterval` is not. The timer keeps firing while
	 * the chain is busy, so without this a period shorter than the work in flight
	 * (say `intervalMs: 50` against the 209 ms `eth_estimateGas` search ADR 0012
	 * measures) appends a mine per tick and they drain afterwards as a burst of
	 * empty blocks — and if mining outruns the period the queue never stops growing.
	 * At most ONE tick is ever waiting: the flag is cleared when the job STARTS, so
	 * a tick that arrives during a mine still schedules the next one.
	 *
	 * It goes THROUGH the serialisation point like every other way a block gets
	 * mined, because a timer is a concurrency source the consumer never sees: it
	 * fires whenever the event loop reaches it, which before this meant in the
	 * middle of whatever `eth_call` happened to be executing.
	 */
	let minePending = false;
	if (miningConfig.type === 'interval') {
		intervalTimer = setInterval(() => {
			if (minePending) return;
			minePending = true;
			// The flag is cleared as the job STARTS rather than when it finishes, so a
			// tick arriving during a mine still schedules the next one, and a mine that
			// THROWS cannot strand the flag and silently stop interval mining.
			void serialise(() => {
				minePending = false;
				return mineBlock();
			});
		}, miningConfig.intervalMs);
	}

	// wrap mine() to persist
	async function mineAndPersist() {
		const r = await mineBlock();
		await persistIfNeeded();
		return r;
	}

	// wrap request so state-changing methods persist after mining
	const baseRequest = request;
	async function persistingRequest(args: RequestArguments): Promise<unknown> {
		const out = await baseRequest(args);
		if (
			((args.method === 'eth_sendRawTransaction' ||
				args.method === 'eth_sendRawTransactionSync' ||
				args.method === 'evm_sendRawTransactionAs' ||
				args.method === 'evm_sendRawTransactionSyncAs') &&
				miningConfig.type === 'auto') ||
			// `evm_mine` mines a block under every mining config, as `node.mine()`
			// does, so it persists like `mine()` does.
			args.method === 'evm_mine'
		) {
			await persistIfNeeded();
		}
		return out;
	}

	// THE PUBLIC SURFACE, AND THE ONLY PLACE THE LOCK IS TAKEN. Everything above
	// this line calls the node's internals DIRECTLY and never through here, which is
	// what makes one promise chain safe: `persistingRequest` reaches `baseRequest`,
	// `mineAndPersist` reaches `mineBlock` and `persistIfNeeded` reaches `dumpState`,
	// none of them re-entering a wrapper. Add an entry point below and it must be
	// serialised too; call one of these wrappers from inside the node and it will
	// wait for itself forever.
	//
	// `dispose` is deliberately NOT serialised: it stops the interval timer and drops
	// the newHeads subscribers, touches no state, and would be useless at the back of
	// a queue it is meant to wind down. Note what that does NOT mean: it does not
	// CANCEL anything already queued. Work accepted before `dispose` still runs to
	// completion, including a `persistence.save()`, and only the timer stops adding
	// more. A caller that needs the node quiet should stop issuing requests and await
	// the ones it holds.
	//
	// `serveOn` is not serialised either, for the reason `dispose` is not: it
	// touches no state. It only relays `request`, which IS serialised, so a request
	// arriving over a served port queues exactly like one made directly.
	const publicRequest = (args: RequestArguments) =>
		serialise(() => persistingRequest(args));
	const node: SlimNode = {
		request: publicRequest,
		mine: () => serialise(mineAndPersist),
		dumpState: () => serialise(dumpState),
		loadState: (state: SerializedState) => serialise(() => loadState(state)),
		computeStateRoot,
		senderMode,
		// Identity only: the engine object itself stays internal, so the reading is a
		// plain value that survives a Worker/comlink boundary unchanged.
		engine: {id: engine.id},
		async getStateRoot() {
			if (!computeStateRoot) {
				throw new RpcError(
					-32004,
					'no state root: this node was created without computeStateRoot. Create it with computeStateRoot: true for a real Merkle-Patricia root',
				);
			}
			// SERIALISED like the rest, because this one READS BY WRITING: it applies
			// the open record to the derived trie, which reads the COMMITTED flat state
			// and refuses to run with a checkpoint open, so a root taken
			// mid-transaction would report a state no block (or cheat) produced.
			return serialise(currentStateRoot);
		},
		onNewHead(cb) {
			headSubs.add(cb);
			return () => headSubs.delete(cb);
		},
		// SERVE `request` ON A HANDED PORT, via `@eip-1193/over-port`, so a consumer
		// on another thread uses this node through `providerOverPort(otherEnd)`.
		//
		// IT LIVES ON THE CORE NODE, NOT ONLY IN `webevm/worker-host`, so the two
		// kinds of node stay interchangeable: `SlimNode` carries it, the one worker
		// proxy forwards it (its `Required<SlimNode>` annotation demands that), and a
		// main-thread node answers the same call in place. The price is that the
		// core imports `@eip-1193/over-port` (about 6 kB of unminified JS, no
		// runtime dependency of its own), which `webevm/worker-client` and
		// `webevm/revm` still do not: the client only TRANSFERS the port, and
		// the consumer brings its own `providerOverPort`.
		//
		// Only `request` is served, bound to the SERIALISED entry point above.
		async serveOn(port: MessagePort) {
			const server = serveProvider({request: publicRequest}, port);
			servedPorts.add(server);
			return {
				async close() {
					server.close();
					servedPorts.delete(server);
				},
			};
		},
		async dispose() {
			if (intervalTimer) clearInterval(intervalTimer);
			headSubs.clear();
			// A disposed node stops answering on every port it was serving, so a
			// consumer is not left talking to a node its owner has let go of.
			for (const server of servedPorts) server.close();
			servedPorts.clear();
		},
	};
	changeSetProbes.set(node, () => ({
		recording: changeSets !== undefined,
		sealedBlocks: sealed.map((r) => r.number),
		headBlock: headBlockChangeSet,
		open: changeSets?.peekChangeSet(),
	}));
	return node;
}
